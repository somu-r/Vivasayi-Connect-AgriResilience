# Vivasayi Connect TN — Sivaganga Demo + Fast2SMS

Flask + SQLite application for cooperative inventory, farmer requests, announcements, SMS/OTP, low-stock alerts, user administration, audit logs and reports. This package includes an **optional, clearly labelled fictional Sivaganga district demo dataset** so you can inspect every module before adding verified real records.

## Windows quick start

1. Extract this ZIP into a **new folder** (do not overwrite the older project folder).
2. Open Command Prompt in the extracted `vivasayi_connect_tn_v2_9` folder — the folder containing `app.py`.
3. Run:

```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
copy .env.example .env
```

4. Open `.env` in Notepad and set a long unique `SECRET_KEY`, a different `OTP_SECRET`, and your Fast2SMS API key. Keep `SMS_PROVIDER=fast2sms`. Never send the API key in chat or commit `.env` to source control.
5. Add sample records to the local database:

```bat
py seed_demo_data.py
```

6. Start the app:

```bat
py app.py
```

Open `http://127.0.0.1:5000`.

## Local demo accounts

- Admin: `demo_admin` / `DemoAdmin@123!`
- Officer: `demo_officer` / `DemoOfficer@123!`
- Farmer: `demo_farmer` / `DemoFarmer@123!`

These demo passwords are intentionally simple to make local testing easy. Change/delete these accounts and seed records before any public deployment. Sample contact numbers use reserved-looking demo values and **must not be used to send SMS**. The seed script does not send SMS.

## Demo data included

The `seed_demo_data.py` script idempotently adds synthetic examples for Sivaganga, Kalaiyarkoil, Manamadurai, Tiruppathur and Devakottai: demo users, cooperative society names, farmer requests in different statuses, stock products, stock movements, announcements, low-stock alert history, notification/delivery history and audit log entries. Society names and people are fictional examples for UI testing; they are not verified official society records. Replace them with verified data before real use. Existing database records are not deleted.

## Fast2SMS setup and test

- Get the API key from the Fast2SMS dashboard's Dev API/API Key section.
- Paste it into `.env` as `FAST2SMS_API_KEY=...` (no quotes are usually needed).
- `SMS_PROVIDER=fast2sms` selects Fast2SMS for announcements, low-stock SMS and SMS OTP.
- Fast2SMS Quick SMS may require account activation, sufficient balance, an eligible route and compliance with current Indian messaging rules. The app's success message means the provider accepted the request, not that the handset received it. Check Fast2SMS delivery reports.
- Do not send SMS to the synthetic demo numbers. Test only with a real, consenting phone number that you control, and verify the number/account settings first.
- `.env` is loaded automatically with `python-dotenv`. Restart the app after changing it.

## If the old project keeps opening

- Stop the old server with `Ctrl+C` in its terminal.
- Extract this ZIP to a new folder with a distinct name.
- In Command Prompt run `cd` to that new folder and use `dir`; confirm `app.py`, `.env`, and `seed_demo_data.py` are in that same folder.
- Run `py app.py` from that folder. If an old database is being reused, inspect `DATABASE_PATH` in `.env`; back up any real database before changing or deleting it.
- Visit `http://127.0.0.1:5000` and hard-refresh with `Ctrl+F5`.

## Security / production note

This is a development demo, not production-ready. Before real deployment, remove demo accounts/data, use strong secrets, configure HTTPS and a production WSGI server, add CSRF protection and rate limiting, set up backups and audit/monitoring, and verify privacy and SMS consent. Do not use the Flask development server for public traffic.

@echo off
cd /d "%~dp0"
echo Vivasayi Connect TN - Sivaganga Demo
if not exist .venv\Scripts\python.exe (
  py -m venv .venv
)
call .venv\Scripts\activate.bat
py -m pip install -r requirements.txt
if not exist .env copy .env.example .env
if not exist vivasayi_v2.db py seed_demo_data.py
py app.py
pause

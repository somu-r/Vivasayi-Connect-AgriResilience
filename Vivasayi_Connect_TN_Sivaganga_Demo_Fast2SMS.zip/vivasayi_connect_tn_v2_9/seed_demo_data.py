"""Seed clearly-labelled fictional Sivaganga demo records for local testing only.
Run: python seed_demo_data.py
Demo logins (change before any real deployment): demo_admin / DemoAdmin@123!
                           demo_officer / DemoOfficer@123!
                           demo_farmer / DemoFarmer@123!
"""
import os, sqlite3
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
import app as application

application.init_db()
db_path = application.DB_PATH
now = datetime.now()
def ts(days=0, hours=0):
    return (now - timedelta(days=days, hours=hours)).strftime('%Y-%m-%d %H:%M:%S')

db = sqlite3.connect(db_path)
db.row_factory = sqlite3.Row
# All identities and contacts are synthetic demo values. Never use them as real contacts.
users = [
 ('demo_admin','admin','DEMO Admin - Sivaganga Operations','0000000001','demo.admin@example.invalid'),
 ('demo_officer','officer','DEMO Society Officer - Sivaganga','0000000002','demo.officer@example.invalid'),
 ('demo_farmer','farmer','DEMO Farmer - Kalaiyarkoil','0000000003','demo.farmer@example.invalid'),
 ('demo_farmer2','farmer','DEMO Farmer - Manamadurai','0000000004','demo.farmer2@example.invalid'),
]
for username, role, name, phone, email in users:
    db.execute('INSERT OR IGNORE INTO users(username,password_hash,role,display_name,phone,email,is_active,created_at) VALUES(?,?,?,?,?,?,1,?)',
      (username, generate_password_hash({'demo_admin':'DemoAdmin@123!','demo_officer':'DemoOfficer@123!','demo_farmer':'DemoFarmer@123!','demo_farmer2':'DemoFarmer2@123!'}[username]),role,name,phone,email,ts(14)))

stock = [
 ('Urea - DEMO','யூரியா - மாதிரி','Fertilizer','உரம்','bag',18,10),
 ('DAP - DEMO','டிஏபி - மாதிரி','Fertilizer','உரம்','bag',7,8),
 ('Paddy Seeds - DEMO','நெல் விதை - மாதிரி','Seeds','விதைகள்','kg',125,25),
 ('Neem Cake - DEMO','வேப்பம் புண்ணாக்கு - மாதிரி','Organic input','இயற்கை இடுபொருள்','kg',42,10),
 ('Sprayer - DEMO','தெளிப்பான் - மாதிரி','Equipment','கருவி','piece',4,2),
]
for product, tamil, cat, tcat, unit, qty, threshold in stock:
    db.execute('INSERT OR IGNORE INTO stock(product,tamil_name,category,tamil_category,unit,quantity,threshold,updated_at) VALUES(?,?,?,?,?,?,?,?)', (product,tamil,cat,tcat,unit,qty,threshold,ts(1)))

# Sample requests use clearly labelled demonstration society names in Sivaganga district.
reqs = [
 ('DEMO Farmer - Kalaiyarkoil','0000000003','Kalaiyarkoil','DEMO - Kalaiyarkoil Primary Agricultural Cooperative Society','Paddy Seeds - DEMO',20,'kg','Sample request only; not a real order.','Pending',ts(0,3)),
 ('DEMO Farmer - Manamadurai','0000000004','Manamadurai','DEMO - Manamadurai Farmers Cooperative Society','Urea - DEMO',3,'bag','Sample request only; not a real order.','Approved',ts(1)),
 ('DEMO Farmer - Sivaganga','0000000005','Sivaganga','DEMO - Sivaganga Agricultural Cooperative Society','DAP - DEMO',2,'bag','Sample request only; not a real order.','Completed',ts(3)),
 ('DEMO Farmer - Tiruppathur','0000000006','Tiruppathur','DEMO - Tiruppathur Farmers Cooperative Society','Neem Cake - DEMO',10,'kg','Sample request only; not a real order.','Pending',ts(0,8)),
 ('DEMO Farmer - Devakottai','0000000007','Devakottai','DEMO - Devakottai Agricultural Cooperative Society','Sprayer - DEMO',1,'piece','Sample request only; not a real order.','Rejected',ts(4)),
]
for row in reqs:
    exists=db.execute('SELECT 1 FROM requests WHERE farmer_name=? AND notes=?',(row[0],row[7])).fetchone()
    if not exists:
      db.execute('INSERT INTO requests(farmer_name,phone,village,society,product,quantity,unit,notes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',row)

announcements = [
 ('DEMO - Paddy seed availability','Sample notice: demo paddy seed stock is available for testing workflows. This is not an official agricultural advisory.','All farmers',ts(1)),
 ('DEMO - Society stock review','Sample notice: officers can review inventory and low-stock items in the demo database.','All officers/admins',ts(2)),
]
for row in announcements:
    db.execute('INSERT INTO announcements(title,message,audience,created_at) SELECT ?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM announcements WHERE title=?)',(*row,row[0]))

for product, move, qty, note, age in [
 ('Urea - DEMO','IN',25,'DEMO opening stock receipt',5),('Urea - DEMO','OUT',7,'DEMO distribution entry',2),
 ('Paddy Seeds - DEMO','IN',150,'DEMO opening stock receipt',6),('DAP - DEMO','OUT',3,'DEMO sample distribution',1)]:
    db.execute('INSERT INTO stock_moves(product,move_type,quantity,note,created_at) SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM stock_moves WHERE note=?)', (product,move,qty,note,ts(age),note))

# Low stock item and notification history are demo-only and will refresh against stock on app access.
db.execute('INSERT OR IGNORE INTO low_stock_alerts(product,quantity,threshold,active,created_at,updated_at) VALUES(?,?,?,?,?,?)',('DAP - DEMO',7,8,1,ts(1),ts(0)))
db.execute("INSERT INTO audit_logs(actor_id,actor_username,actor_role,action,target,details,ip_address,created_at) SELECT (SELECT id FROM users WHERE username='demo_admin'),'demo_admin','admin','DEMO_seed_completed','Sivaganga sample dataset','Synthetic sample records inserted; no real notification sent','127.0.0.1',? WHERE NOT EXISTS (SELECT 1 FROM audit_logs WHERE action='DEMO_seed_completed')",(ts(0),))
# Sample delivery/notification history does not send messages.
first_announcement=db.execute("SELECT id FROM announcements WHERE title='DEMO - Paddy seed availability' ORDER BY id DESC LIMIT 1").fetchone()
if first_announcement:
    db.execute("INSERT INTO announcement_deliveries(announcement_id,recipient_user_id,recipient,channel,status,error,created_at) SELECT ?, (SELECT id FROM users WHERE username='demo_farmer'),'******0003','sms','demo','DEMO only: SMS was not sent',? WHERE NOT EXISTS (SELECT 1 FROM announcement_deliveries WHERE announcement_id=? AND status='demo')",(first_announcement['id'],ts(1),first_announcement['id']))
db.execute("INSERT INTO low_stock_notifications(product,recipient,channel,status,error,created_at) SELECT 'DAP - DEMO','demo_officer','sms','demo','DEMO only: SMS was not sent',? WHERE NOT EXISTS (SELECT 1 FROM low_stock_notifications WHERE product='DAP - DEMO' AND status='demo')",(ts(0),))
db.commit(); db.close()
print('DEMO Sivaganga sample data added. These are fictional records; no SMS was sent.')
print('Login: demo_admin / DemoAdmin@123! | demo_officer / DemoOfficer@123! | demo_farmer / DemoFarmer@123!')
print('Change/remove demo credentials before deployment. Do not use demo data as real society records.')

# Vivasayi Connect TN V2.2

A bilingual English/Tamil Flask + SQLite prototype for farmer requests and cooperative stock coordination, now with login and role-based dashboards.

## What's new in V2.1
- Login/logout with password hashes (Werkzeug).
- Separate Farmer, Officer and Admin dashboards.
- Role checks on protected routes: farmers can submit requests and see requests matching their registered demo phone; officers manage requests, inventory and announcement logs; admins see account/system summaries and officer tools.
- Demo accounts are seeded on first run (listed below). These are for local testing only.

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Farmer | `farmer` | `farmer123` |
| Officer | `officer` | `officer123` |
| Admin | `admin` | `admin123` |

**Important:** change/remove demo accounts, set a strong random `SECRET_KEY`, enable HTTPS, add CSRF protection, and review privacy/security before any real deployment. This is not production-ready authentication.

## Other features
- Tamil/English language toggle
- Farmer request form and tracking IDs
- Request search and statuses: Pending, Approved, Fulfilled, Rejected
- Stock-in/stock-out inventory updates with movement history
- Low-stock indicators using configurable thresholds
- Announcement log (**no real SMS is sent**)
- Browser-based IVR simulation (**no real phone calls**)
- `/health` endpoint

## Run on Windows PowerShell
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run on macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Render deployment
Build command: `pip install -r requirements.txt`
Start command: `gunicorn app:app`
Set `SECRET_KEY` to a long random value. For durable data, configure persistent storage and set `DATABASE_PATH` to a file on that disk, or use managed PostgreSQL. SQLite data on ephemeral hosting may reset.

## Limitations
Sample stock only; not connected to government/cooperative systems. Announcement and IVR features are demo-only. Farmer request visibility currently matches the demo account's phone number, so use that account's phone on the request form. Authentication/role checks are a prototype, not a security-reviewed production system.


## V2.2 additions
- Admin user management: create farmer/officer/admin accounts, enable/disable accounts, and reset passwords.
- Users can change their own password after verifying the current password.
- Audit log records successful/failed logins, logout, account creation, account enable/disable, password resets and self-service password changes. Admin-only audit view shows the latest 300 events.
- Passwords are stored as Werkzeug hashes. Existing V2.1 SQLite databases are migrated with `is_active` and `created_at` columns.

## Security notes
This is still a demo prototype. Password reset is an administrator-issued manual reset (no email/SMS delivery). Before public deployment, set a strong random `SECRET_KEY`, add CSRF protection/rate limiting and secure HTTPS cookie settings, back up the database, and replace/remove demo credentials. Audit logs contain IP addresses and should be protected as personal data.

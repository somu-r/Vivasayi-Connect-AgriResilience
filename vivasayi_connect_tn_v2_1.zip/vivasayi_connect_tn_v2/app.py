import os, sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(app.root_path, "vivasayi_v2.db"))

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None: db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('farmer','officer','admin')),
      display_name TEXT NOT NULL, phone TEXT
    );
    CREATE TABLE IF NOT EXISTS stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT UNIQUE NOT NULL,
      tamil_name TEXT NOT NULL, category TEXT NOT NULL, tamil_category TEXT NOT NULL,
      unit TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, threshold REAL NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_name TEXT NOT NULL, phone TEXT,
      village TEXT NOT NULL, society TEXT NOT NULL, product TEXT NOT NULL,
      quantity REAL NOT NULL, unit TEXT NOT NULL, notes TEXT, status TEXT NOT NULL DEFAULT 'Pending',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      audience TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_moves (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, move_type TEXT NOT NULL,
      quantity REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
    );
    """)
    # Seed demo accounts once; change these credentials before any real deployment.
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        demo_users = [
          ("farmer", generate_password_hash("farmer123"), "farmer", "Demo Farmer", "9000000001"),
          ("officer", generate_password_hash("officer123"), "officer", "Demo Officer", "9000000002"),
          ("admin", generate_password_hash("admin123"), "admin", "Demo Admin", "9000000003"),
        ]
        db.executemany("INSERT INTO users(username,password_hash,role,display_name,phone) VALUES(?,?,?,?,?)", demo_users)
    if db.execute("SELECT COUNT(*) FROM stock").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        seed = [
          ("Urea","யூரியா","Fertilizer","உரம்","bag",2,5),
          ("DAP","டிஏபி","Fertilizer","உரம்","bag",18,5),
          ("Paddy Seeds","நெல் விதைகள்","Seeds","விதைகள்","kg",45,10),
          ("Potash","பொட்டாஷ்","Fertilizer","உரம்","bag",8,5),
          ("Neem Pesticide","வேப்பம் சார்ந்த பூச்சிக்கொல்லி","Crop care","பயிர் பராமரிப்பு","litre",12,5)]
        db.executemany("""INSERT INTO stock(product,tamil_name,category,tamil_category,unit,quantity,threshold,updated_at)
          VALUES(?,?,?,?,?,?,?,?)""", [( *r, now) for r in seed])
        db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
          ("Welcome to Vivasayi Connect TN V2","Demo system ready. Verify stock before visiting the society.","All farmers",now))
    db.commit(); db.close()

@app.before_request
def before():
    init_db()
    session.setdefault("lang","en")

def login_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                flash("Please log in to continue.", "error")
                return redirect(url_for("login", next=request.path))
            if roles and session.get("role") not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator

@app.context_processor
def globals_for_templates():
    return {"lang":session.get("lang","en")}

@app.route("/language/<code>")
def language(code):
    if code in ("en","ta"): session["lang"]=code
    return redirect(request.referrer or url_for("index"))

@app.route("/")
@login_required("officer", "admin")
def index():
    return redirect(url_for("dashboard"))
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    stats={"products":len(stock),"low":sum(x["quantity"]<=x["threshold"] for x in stock),
      "pending":db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
      "requests":db.execute("SELECT COUNT(*) FROM requests").fetchone()[0]}
    recent=db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("index.html",stock=stock,stats=stats,recent=recent)

@app.route("/farmer",methods=["GET","POST"])
@login_required("farmer", "officer", "admin")
def farmer():
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    if request.method=="POST":
        name=request.form.get("farmer_name","").strip(); village=request.form.get("village","").strip()
        society=request.form.get("society","").strip(); product=request.form.get("product","")
        phone=request.form.get("phone","").strip(); notes=request.form.get("notes","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        item=db.execute("SELECT unit FROM stock WHERE product=?",(product,)).fetchone()
        if not name or not village or not society or not item or qty<=0:
            flash("Please complete required fields and enter a quantity greater than zero.","error")
        else:
            db.execute("""INSERT INTO requests(farmer_name,phone,village,society,product,quantity,unit,notes,created_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(name,phone,village,society,product,qty,item["unit"],notes,datetime.now().strftime("%Y-%m-%d %H:%M")))
            db.commit(); flash("Request submitted successfully. Check Requests to see its ID and status.","success")
            return redirect(url_for("requests_page"))
    return render_template("farmer.html",stock=stock)

@app.route("/requests")
@login_required("officer", "admin")
def requests_page():
    db=get_db(); q=request.args.get("q","").strip(); status=request.args.get("status","").strip()
    sql="SELECT * FROM requests WHERE 1=1"; args=[]
    if q:
        sql+=" AND (farmer_name LIKE ? OR village LIKE ? OR society LIKE ? OR CAST(id AS TEXT)=?)"
        args += [f"%{q}%"]*3+[q]
    if status in ("Pending","Approved","Fulfilled","Rejected"):
        sql+=" AND status=?"; args.append(status)
    rows=db.execute(sql+" ORDER BY id DESC",args).fetchall()
    return render_template("requests.html",rows=rows,q=q,status=status)

@app.route("/requests/<int:req_id>/status",methods=["POST"])
@login_required("officer", "admin")
def update_status(req_id):
    status=request.form.get("status","")
    if status not in ("Pending","Approved","Fulfilled","Rejected"): flash("Invalid status.","error")
    else:
        db=get_db()
        if db.execute("SELECT id FROM requests WHERE id=?",(req_id,)).fetchone():
            db.execute("UPDATE requests SET status=? WHERE id=?",(status,req_id)); db.commit()
            flash(f"Request #{req_id} updated to {status}.","success")
        else: flash("Request not found.","error")
    return redirect(request.referrer or url_for("requests_page"))

@app.route("/inventory",methods=["GET","POST"])
@login_required("officer", "admin")
def inventory():
    db=get_db()
    if request.method=="POST":
        product=request.form.get("product",""); move=request.form.get("move_type","")
        note=request.form.get("note","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        row=db.execute("SELECT * FROM stock WHERE product=?",(product,)).fetchone()
        if not row or qty<=0 or move not in ("Stock In","Stock Out"):
            flash("Choose a product and enter a positive quantity.","error")
        elif move=="Stock Out" and row["quantity"]<qty:
            flash("Stock out quantity exceeds available stock.","error")
        else:
            newqty=row["quantity"]+qty if move=="Stock In" else row["quantity"]-qty
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            db.execute("UPDATE stock SET quantity=?,updated_at=? WHERE product=?",(newqty,now,product))
            db.execute("INSERT INTO stock_moves(product,move_type,quantity,note,created_at) VALUES(?,?,?,?,?)",(product,move,qty,note,now))
            db.commit(); flash(f"{product} stock updated.","success")
        return redirect(url_for("inventory"))
    stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    moves=db.execute("SELECT * FROM stock_moves ORDER BY id DESC LIMIT 15").fetchall()
    return render_template("inventory.html",stock=stock,moves=moves)

@app.route("/announcements",methods=["GET","POST"])
@login_required("officer", "admin")
def announcements():
    db=get_db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); message=request.form.get("message","").strip()
        audience=request.form.get("audience","All farmers").strip()
        if not title or not message: flash("Enter a title and message.","error")
        else:
            db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
             (title,message,audience,datetime.now().strftime("%Y-%m-%d %H:%M"))); db.commit()
            flash("Announcement saved to demo log only. No real SMS was sent.","success")
            return redirect(url_for("announcements"))
    rows=db.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    return render_template("announcements.html",rows=rows)

@app.route("/ivr")
@login_required("farmer", "officer", "admin")
def ivr(): return render_template("ivr.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["id"], username=user["username"], role=user["role"],
                           display_name=user["display_name"], phone=user["phone"], lang="en")
            flash("Welcome, " + user["display_name"] + "!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required()
def dashboard():
    role = session.get("role")
    db = get_db()
    if role == "officer":
        stats = {"pending": db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0],
                 "products": db.execute("SELECT COUNT(*) FROM stock").fetchone()[0]}
        recent = db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 6").fetchall()
        return render_template("officer_dashboard.html", stats=stats, recent=recent)
    if role == "admin":
        stats = {"users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                 "farmers": db.execute("SELECT COUNT(*) FROM users WHERE role='farmer'").fetchone()[0],
                 "officers": db.execute("SELECT COUNT(*) FROM users WHERE role='officer'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0]}
        users = db.execute("SELECT username,display_name,role FROM users ORDER BY role,username").fetchall()
        return render_template("admin_dashboard.html", stats=stats, users=users)
    # Farmer sees only requests associated with their demo account phone.
    rows = db.execute("SELECT * FROM requests WHERE phone=? ORDER BY id DESC", (session.get("phone", ""),)).fetchall()
    stock = db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    return render_template("farmer_dashboard.html", rows=rows, stock=stock)

@app.errorhandler(403)
def forbidden(_):
    return render_template("403.html"), 403

@app.route("/health")
def health(): return {"status":"ok","app":"Vivasayi Connect TN V2.1"}

@app.errorhandler(404)
def not_found(_): return render_template("404.html"),404

if __name__=="__main__": app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")

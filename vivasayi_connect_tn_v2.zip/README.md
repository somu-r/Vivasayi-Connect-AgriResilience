# Vivasayi Connect TN V2

A bilingual English/Tamil Flask prototype for farmer requests and cooperative stock coordination.

## Features
- Tamil/English language toggle
- Farmer request form and request tracking IDs
- Request search and statuses: Pending, Approved, Fulfilled, Rejected
- Stock-in/stock-out inventory updates with movement history
- Automatic low-stock indicators using configurable thresholds
- Announcement log (demo only; **no SMS is sent**)
- Browser-based IVR simulation (no real calls)
- Dashboard summary and `/health` endpoint

## Run on Windows PowerShell
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run on macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Render deployment
Build command: `pip install -r requirements.txt`
Start command: `gunicorn app:app`
Set `SECRET_KEY` to a long random value. For durable data, configure persistent storage and set `DATABASE_PATH` to a file on that disk, or use managed PostgreSQL. SQLite data on ephemeral hosting may reset.

## Important limitations
This is a demo using sample stock, not connected to government/cooperative systems. Announcements are stored in the app only; no SMS is sent. IVR is a browser simulation, not a phone integration. Authentication and role permissions are not implemented, so do not enter real farmer personal data or use as a production system.

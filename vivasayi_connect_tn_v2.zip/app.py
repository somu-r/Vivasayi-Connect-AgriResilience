import os, sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session, g

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(app.root_path, "vivasayi_v2.db"))

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None: db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT UNIQUE NOT NULL,
      tamil_name TEXT NOT NULL, category TEXT NOT NULL, tamil_category TEXT NOT NULL,
      unit TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, threshold REAL NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_name TEXT NOT NULL, phone TEXT,
      village TEXT NOT NULL, society TEXT NOT NULL, product TEXT NOT NULL,
      quantity REAL NOT NULL, unit TEXT NOT NULL, notes TEXT, status TEXT NOT NULL DEFAULT 'Pending',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      audience TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_moves (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, move_type TEXT NOT NULL,
      quantity REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
    );
    """)
    if db.execute("SELECT COUNT(*) FROM stock").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        seed = [
          ("Urea","யூரியா","Fertilizer","உரம்","bag",2,5),
          ("DAP","டிஏபி","Fertilizer","உரம்","bag",18,5),
          ("Paddy Seeds","நெல் விதைகள்","Seeds","விதைகள்","kg",45,10),
          ("Potash","பொட்டாஷ்","Fertilizer","உரம்","bag",8,5),
          ("Neem Pesticide","வேப்பம் சார்ந்த பூச்சிக்கொல்லி","Crop care","பயிர் பராமரிப்பு","litre",12,5)]
        db.executemany("""INSERT INTO stock(product,tamil_name,category,tamil_category,unit,quantity,threshold,updated_at)
          VALUES(?,?,?,?,?,?,?,?)""", [( *r, now) for r in seed])
        db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
          ("Welcome to Vivasayi Connect TN V2","Demo system ready. Verify stock before visiting the society.","All farmers",now))
    db.commit(); db.close()

@app.before_request
def before():
    init_db()
    session.setdefault("lang","en")

@app.context_processor
def globals_for_templates():
    return {"lang":session.get("lang","en")}

@app.route("/language/<code>")
def language(code):
    if code in ("en","ta"): session["lang"]=code
    return redirect(request.referrer or url_for("index"))

@app.route("/")
def index():
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    stats={"products":len(stock),"low":sum(x["quantity"]<=x["threshold"] for x in stock),
      "pending":db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
      "requests":db.execute("SELECT COUNT(*) FROM requests").fetchone()[0]}
    recent=db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("index.html",stock=stock,stats=stats,recent=recent)

@app.route("/farmer",methods=["GET","POST"])
def farmer():
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    if request.method=="POST":
        name=request.form.get("farmer_name","").strip(); village=request.form.get("village","").strip()
        society=request.form.get("society","").strip(); product=request.form.get("product","")
        phone=request.form.get("phone","").strip(); notes=request.form.get("notes","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        item=db.execute("SELECT unit FROM stock WHERE product=?",(product,)).fetchone()
        if not name or not village or not society or not item or qty<=0:
            flash("Please complete required fields and enter a quantity greater than zero.","error")
        else:
            db.execute("""INSERT INTO requests(farmer_name,phone,village,society,product,quantity,unit,notes,created_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(name,phone,village,society,product,qty,item["unit"],notes,datetime.now().strftime("%Y-%m-%d %H:%M")))
            db.commit(); flash("Request submitted successfully. Check Requests to see its ID and status.","success")
            return redirect(url_for("requests_page"))
    return render_template("farmer.html",stock=stock)

@app.route("/requests")
def requests_page():
    db=get_db(); q=request.args.get("q","").strip(); status=request.args.get("status","").strip()
    sql="SELECT * FROM requests WHERE 1=1"; args=[]
    if q:
        sql+=" AND (farmer_name LIKE ? OR village LIKE ? OR society LIKE ? OR CAST(id AS TEXT)=?)"
        args += [f"%{q}%"]*3+[q]
    if status in ("Pending","Approved","Fulfilled","Rejected"):
        sql+=" AND status=?"; args.append(status)
    rows=db.execute(sql+" ORDER BY id DESC",args).fetchall()
    return render_template("requests.html",rows=rows,q=q,status=status)

@app.route("/requests/<int:req_id>/status",methods=["POST"])
def update_status(req_id):
    status=request.form.get("status","")
    if status not in ("Pending","Approved","Fulfilled","Rejected"): flash("Invalid status.","error")
    else:
        db=get_db()
        if db.execute("SELECT id FROM requests WHERE id=?",(req_id,)).fetchone():
            db.execute("UPDATE requests SET status=? WHERE id=?",(status,req_id)); db.commit()
            flash(f"Request #{req_id} updated to {status}.","success")
        else: flash("Request not found.","error")
    return redirect(request.referrer or url_for("requests_page"))

@app.route("/inventory",methods=["GET","POST"])
def inventory():
    db=get_db()
    if request.method=="POST":
        product=request.form.get("product",""); move=request.form.get("move_type","")
        note=request.form.get("note","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        row=db.execute("SELECT * FROM stock WHERE product=?",(product,)).fetchone()
        if not row or qty<=0 or move not in ("Stock In","Stock Out"):
            flash("Choose a product and enter a positive quantity.","error")
        elif move=="Stock Out" and row["quantity"]<qty:
            flash("Stock out quantity exceeds available stock.","error")
        else:
            newqty=row["quantity"]+qty if move=="Stock In" else row["quantity"]-qty
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            db.execute("UPDATE stock SET quantity=?,updated_at=? WHERE product=?",(newqty,now,product))
            db.execute("INSERT INTO stock_moves(product,move_type,quantity,note,created_at) VALUES(?,?,?,?,?)",(product,move,qty,note,now))
            db.commit(); flash(f"{product} stock updated.","success")
        return redirect(url_for("inventory"))
    stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    moves=db.execute("SELECT * FROM stock_moves ORDER BY id DESC LIMIT 15").fetchall()
    return render_template("inventory.html",stock=stock,moves=moves)

@app.route("/announcements",methods=["GET","POST"])
def announcements():
    db=get_db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); message=request.form.get("message","").strip()
        audience=request.form.get("audience","All farmers").strip()
        if not title or not message: flash("Enter a title and message.","error")
        else:
            db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
             (title,message,audience,datetime.now().strftime("%Y-%m-%d %H:%M"))); db.commit()
            flash("Announcement saved to demo log only. No real SMS was sent.","success")
            return redirect(url_for("announcements"))
    rows=db.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    return render_template("announcements.html",rows=rows)

@app.route("/ivr")
def ivr(): return render_template("ivr.html")

@app.route("/health")
def health(): return {"status":"ok","app":"Vivasayi Connect TN V2"}

@app.errorhandler(404)
def not_found(_): return render_template("404.html"),404

if __name__=="__main__": app.run(debug=True)

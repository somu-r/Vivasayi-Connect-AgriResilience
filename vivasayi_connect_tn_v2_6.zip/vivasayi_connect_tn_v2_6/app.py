import os, sqlite3, re, secrets, hashlib, smtplib, ssl, urllib.parse, urllib.request, json, csv, io
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(app.root_path, "vivasayi_v2.db"))

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None: db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('farmer','officer','admin')),
      display_name TEXT NOT NULL, phone TEXT, email TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS password_otps (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, channel TEXT NOT NULL,
      destination TEXT NOT NULL, otp_hash TEXT NOT NULL, expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0, used INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, actor_username TEXT, actor_role TEXT,
      action TEXT NOT NULL, target TEXT, details TEXT, ip_address TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT UNIQUE NOT NULL,
      tamil_name TEXT NOT NULL, category TEXT NOT NULL, tamil_category TEXT NOT NULL,
      unit TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, threshold REAL NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_name TEXT NOT NULL, phone TEXT,
      village TEXT NOT NULL, society TEXT NOT NULL, product TEXT NOT NULL,
      quantity REAL NOT NULL, unit TEXT NOT NULL, notes TEXT, status TEXT NOT NULL DEFAULT 'Pending',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      audience TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS low_stock_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL UNIQUE, quantity REAL NOT NULL,
      threshold REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_moves (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, move_type TEXT NOT NULL,
      quantity REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS low_stock_notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, recipient TEXT NOT NULL,
      channel TEXT NOT NULL, status TEXT NOT NULL, error TEXT, created_at TEXT NOT NULL
    );
    """)
    # Migrate existing V2.1 databases safely.
    user_cols = {row[1] for row in db.execute("PRAGMA table_info(users)").fetchall()}
    if "is_active" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
    if "created_at" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN created_at TEXT NOT NULL DEFAULT ''")
    if "email" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''")
    # Seed demo accounts once; change these credentials before any real deployment.
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        demo_users = [
          ("farmer", generate_password_hash("farmer123"), "farmer", "Demo Farmer", "9000000001"),
          ("officer", generate_password_hash("officer123"), "officer", "Demo Officer", "9000000002"),
          ("admin", generate_password_hash("admin123"), "admin", "Demo Admin", "9000000003"),
        ]
        created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        db.executemany("INSERT INTO users(username,password_hash,role,display_name,phone,created_at) VALUES(?,?,?,?,?,?)",
                       [(*u, created) for u in demo_users])
    if db.execute("SELECT COUNT(*) FROM stock").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        seed = [
          ("Urea","யூரியா","Fertilizer","உரம்","bag",2,5),
          ("DAP","டிஏபி","Fertilizer","உரம்","bag",18,5),
          ("Paddy Seeds","நெல் விதைகள்","Seeds","விதைகள்","kg",45,10),
          ("Potash","பொட்டாஷ்","Fertilizer","உரம்","bag",8,5),
          ("Neem Pesticide","வேப்பம் சார்ந்த பூச்சிக்கொல்லி","Crop care","பயிர் பராமரிப்பு","litre",12,5)]
        db.executemany("""INSERT INTO stock(product,tamil_name,category,tamil_category,unit,quantity,threshold,updated_at)
          VALUES(?,?,?,?,?,?,?,?)""", [( *r, now) for r in seed])
        db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
          ("Welcome to Vivasayi Connect TN V2","Demo system ready. Verify stock before visiting the society.","All farmers",now))
    db.commit(); db.close()

@app.before_request
def before():
    init_db()
    session.setdefault("lang","en")
    # Maintain an in-app alert for every item currently at/below its threshold.
    try:
        db = sqlite3.connect(DB_PATH)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        low = db.execute("SELECT product,quantity,threshold FROM stock WHERE quantity<=threshold").fetchall()
        low_names = {r[0] for r in low}
        db.execute("UPDATE low_stock_alerts SET active=0 WHERE active=1")
        for product, quantity, threshold in low:
            db.execute("""INSERT INTO low_stock_alerts(product,quantity,threshold,active,created_at,updated_at)
                VALUES(?,?,?,1,?,?) ON CONFLICT(product) DO UPDATE SET quantity=excluded.quantity,
                threshold=excluded.threshold,active=1,updated_at=excluded.updated_at""",
                (product, quantity, threshold, now, now))
        db.commit(); db.close()
    except sqlite3.Error:
        pass

def otp_digest(code, user_id):
    pepper = os.environ.get("OTP_SECRET", app.secret_key)
    return hashlib.sha256(f"{pepper}:{user_id}:{code}".encode()).hexdigest()

def mask_destination(value, channel):
    value = value or ""
    if channel == "email" and "@" in value:
        local, domain = value.split("@", 1)
        return (local[:1] + "***@" + domain)
    return ("*" * max(0, len(value)-4)) + value[-4:]

def deliver_otp(channel, destination, code):
    """Send through configured SMTP or Twilio; return (sent, demo_code_visible)."""
    if channel == "email" and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
        msg = (f"From: {os.environ['SMTP_FROM']}\r\nTo: {destination}\r\n"
               f"Subject: Vivasayi Connect TN password reset OTP\r\n\r\n"
               f"Your password reset code is {code}. It expires in 10 minutes. Do not share it.")
        host = os.environ["SMTP_HOST"]; port = int(os.environ.get("SMTP_PORT", "587"))
        with smtplib.SMTP(host, port, timeout=10) as server:
            server.starttls(context=ssl.create_default_context())
            if os.environ.get("SMTP_USER"):
                server.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            server.sendmail(os.environ["SMTP_FROM"], [destination], msg.encode())
        return True, False
    if channel == "sms" and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
        sid = os.environ["TWILIO_ACCOUNT_SID"]
        url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
        data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"],
             "Body": f"Vivasayi Connect TN password reset code: {code}. Expires in 10 minutes. Do not share."}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        import base64
        token = base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode()
        req.add_header("Authorization", "Basic " + token)
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=12) as response:
            if response.status not in (200, 201): raise RuntimeError("SMS provider rejected request")
        return True, False
    # Local demo only: do not expose OTP outside development.
    if os.environ.get("APP_ENV", "development").lower() != "production":
        app.logger.warning("DEMO password-reset OTP for %s: %s", destination, code)
        return False, True
    raise RuntimeError("OTP delivery is not configured")

def deliver_low_stock(channel, destination, product, quantity, threshold, unit):
    """Deliver an inventory alert using configured SMTP or Twilio; never expose demo secrets."""
    subject = f"Low stock alert: {product}"
    body = (f"Vivasayi Connect TN stock alert\n\n{product} is low: current quantity "
            f"{quantity:g} {unit}; threshold {threshold:g} {unit}. Please arrange replenishment.")
    if channel == "email" and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
        from email.message import EmailMessage
        msg = EmailMessage(); msg["From"] = os.environ["SMTP_FROM"]
        msg["To"] = destination; msg["Subject"] = subject; msg.set_content(body)
        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.environ.get("SMTP_PORT", "587")), timeout=12) as server:
            server.starttls(context=ssl.create_default_context())
            if os.environ.get("SMTP_USER"):
                server.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            server.send_message(msg)
        return
    if channel == "sms" and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
        sid = os.environ["TWILIO_ACCOUNT_SID"]
        url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
        data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"],
            "Body": f"Vivasayi Connect: LOW STOCK - {product}: {quantity:g} {unit} left; threshold {threshold:g}. Please replenish."}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        import base64
        token = base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode()
        req.add_header("Authorization", "Basic " + token)
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=12) as response:
            if response.status not in (200, 201): raise RuntimeError("SMS provider rejected request")
        return
    raise RuntimeError(f"{channel.upper()} provider is not configured")

def notify_low_stock(product, quantity, threshold, unit):
    """Notify active officers/admins once when stock crosses into low-stock state."""
    db = get_db()
    recipients = db.execute("SELECT username,phone,email FROM users WHERE is_active=1 AND role IN ('admin','officer')").fetchall()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    configured = []
    for user in recipients:
        if user["email"] and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
            configured.append((user["username"], "email", user["email"]))
        if user["phone"] and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
            configured.append((user["username"], "sms", user["phone"]))
    if not configured:
        app.logger.warning("LOW STOCK ALERT NOT SENT: no configured SMS/email provider or recipient for %s", product)
        db.execute("INSERT INTO low_stock_notifications(product,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?)",
                   (product, "", "none", "failed", "No configured provider/recipient", now)); db.commit()
        return
    for username, channel, destination in configured:
        status, error = "sent", None
        try:
            deliver_low_stock(channel, destination, product, quantity, threshold, unit)
        except Exception as exc:
            status, error = "failed", str(exc)[:300]
            app.logger.error("Low-stock %s delivery failed for %s: %s", channel, username, error)
        db.execute("INSERT INTO low_stock_notifications(product,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?)",
                   (product, username, channel, status, error, now))
    db.commit()

def log_audit(action, target="", details=""):
    db = get_db()
    db.execute("""INSERT INTO audit_logs(actor_id,actor_username,actor_role,action,target,details,ip_address,created_at)
                  VALUES(?,?,?,?,?,?,?,?)""",
               (session.get("user_id"), session.get("username"), session.get("role"), action[:100],
                str(target)[:200], str(details)[:500], (request.remote_addr or "")[:100],
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    db.commit()

def login_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                flash("Please log in to continue.", "error")
                return redirect(url_for("login", next=request.path))
            if roles and session.get("role") not in roles:
                abort(403)
            active = get_db().execute("SELECT is_active FROM users WHERE id=?", (session.get("user_id"),)).fetchone()
            if not active or not active["is_active"]:
                session.clear()
                flash("This account is disabled. Contact an administrator.", "error")
                return redirect(url_for("login"))
            return view(*args, **kwargs)
        return wrapped
    return decorator

@app.context_processor
def globals_for_templates():
    return {"lang":session.get("lang","en")}

@app.route("/language/<code>")
def language(code):
    if code in ("en","ta"): session["lang"]=code
    return redirect(request.referrer or url_for("index"))

@app.route("/")
@login_required("officer", "admin")
def index():
    return redirect(url_for("dashboard"))
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    stats={"products":len(stock),"low":sum(x["quantity"]<=x["threshold"] for x in stock),
      "pending":db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
      "requests":db.execute("SELECT COUNT(*) FROM requests").fetchone()[0]}
    recent=db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("index.html",stock=stock,stats=stats,recent=recent)

@app.route("/farmer",methods=["GET","POST"])
@login_required("farmer", "officer", "admin")
def farmer():
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    if request.method=="POST":
        name=request.form.get("farmer_name","").strip(); village=request.form.get("village","").strip()
        society=request.form.get("society","").strip(); product=request.form.get("product","")
        phone=request.form.get("phone","").strip(); notes=request.form.get("notes","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        item=db.execute("SELECT unit FROM stock WHERE product=?",(product,)).fetchone()
        if not name or not village or not society or not item or qty<=0:
            flash("Please complete required fields and enter a quantity greater than zero.","error")
        else:
            db.execute("""INSERT INTO requests(farmer_name,phone,village,society,product,quantity,unit,notes,created_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(name,phone,village,society,product,qty,item["unit"],notes,datetime.now().strftime("%Y-%m-%d %H:%M")))
            db.commit(); flash("Request submitted successfully. Check your dashboard to see its status.","success")
            return redirect(url_for("dashboard"))
    return render_template("farmer.html",stock=stock)

@app.route("/requests")
@login_required("officer", "admin")
def requests_page():
    db=get_db(); q=request.args.get("q","").strip(); status=request.args.get("status","").strip()
    sql="SELECT * FROM requests WHERE 1=1"; args=[]
    if q:
        sql+=" AND (farmer_name LIKE ? OR village LIKE ? OR society LIKE ? OR CAST(id AS TEXT)=?)"
        args += [f"%{q}%"]*3+[q]
    if status in ("Pending","Approved","Fulfilled","Rejected"):
        sql+=" AND status=?"; args.append(status)
    rows=db.execute(sql+" ORDER BY id DESC",args).fetchall()
    return render_template("requests.html",rows=rows,q=q,status=status)

@app.route("/requests/<int:req_id>/status",methods=["POST"])
@login_required("officer", "admin")
def update_status(req_id):
    status=request.form.get("status","")
    if status not in ("Pending","Approved","Fulfilled","Rejected"): flash("Invalid status.","error")
    else:
        db=get_db()
        if db.execute("SELECT id FROM requests WHERE id=?",(req_id,)).fetchone():
            db.execute("UPDATE requests SET status=? WHERE id=?",(status,req_id)); db.commit()
            flash(f"Request #{req_id} updated to {status}.","success")
        else: flash("Request not found.","error")
    return redirect(request.referrer or url_for("requests_page"))

@app.route("/inventory",methods=["GET","POST"])
@login_required("officer", "admin")
def inventory():
    db=get_db()
    if request.method=="POST":
        product=request.form.get("product",""); move=request.form.get("move_type","")
        note=request.form.get("note","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        row=db.execute("SELECT * FROM stock WHERE product=?",(product,)).fetchone()
        if not row or qty<=0 or move not in ("Stock In","Stock Out"):
            flash("Choose a product and enter a positive quantity.","error")
        elif move=="Stock Out" and row["quantity"]<qty:
            flash("Stock out quantity exceeds available stock.","error")
        else:
            newqty=row["quantity"]+qty if move=="Stock In" else row["quantity"]-qty
            was_low = row["quantity"] <= row["threshold"]
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            db.execute("UPDATE stock SET quantity=?,updated_at=? WHERE product=?",(newqty,now,product))
            db.execute("INSERT INTO stock_moves(product,move_type,quantity,note,created_at) VALUES(?,?,?,?,?)",(product,move,qty,note,now))
            db.commit()
            # Send only on the transition from healthy stock to low stock; no repeated SMS per page load.
            if not was_low and newqty <= row["threshold"]:
                notify_low_stock(product, newqty, row["threshold"], row["unit"])
                log_audit("low_stock_notification_triggered", product, f"quantity={newqty}; threshold={row['threshold']}")
            flash(f"{product} stock updated.","success")
        return redirect(url_for("inventory"))
    stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    moves=db.execute("SELECT * FROM stock_moves ORDER BY id DESC LIMIT 15").fetchall()
    return render_template("inventory.html",stock=stock,moves=moves)

@app.route("/announcements",methods=["GET","POST"])
@login_required("officer", "admin")
def announcements():
    db=get_db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); message=request.form.get("message","").strip()
        audience=request.form.get("audience","All farmers").strip()
        if not title or not message: flash("Enter a title and message.","error")
        else:
            db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
             (title,message,audience,datetime.now().strftime("%Y-%m-%d %H:%M"))); db.commit()
            flash("Announcement saved to demo log only. No real SMS was sent.","success")
            return redirect(url_for("announcements"))
    rows=db.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    return render_template("announcements.html",rows=rows)

@app.route("/ivr")
@login_required("farmer", "officer", "admin")
def ivr(): return render_template("ivr.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        name = request.form.get("display_name", "").strip()
        phone = re.sub(r"[\s()-]", "", request.form.get("phone", "").strip())
        email = request.form.get("email", "").strip().lower()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if not all((name, phone, email, username, password, confirm)):
            flash("Please complete every field.", "error")
        elif not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username):
            flash("Username must be 3–30 characters (letters, numbers, ., _ or -).", "error")
        elif not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            flash("Enter a valid email address.", "error")
        elif len(re.sub(r"\D", "", phone)) < 10:
            flash("Enter a valid mobile number including country code if needed.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            db = get_db()
            exists = db.execute("SELECT 1 FROM users WHERE username=? OR lower(email)=? OR phone=?", (username, email, phone)).fetchone()
            if exists:
                flash("Username, email or mobile number is already registered.", "error")
            else:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                db.execute("INSERT INTO users(username,password_hash,role,display_name,phone,email,is_active,created_at) VALUES(?,?,?,?,?,?,1,?)",
                           (username, generate_password_hash(password), "farmer", name, phone, email, now))
                db.commit()
                flash("Account created successfully. Please log in.", "success")
                return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and user["is_active"] and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["id"], username=user["username"], role=user["role"],
                           display_name=user["display_name"], phone=user["phone"], lang="en")
            log_audit("login_success", user["username"], "Successful login")
            flash("Welcome, " + user["display_name"] + "!", "success")
            return redirect(url_for("dashboard"))
        log_audit("login_failed", username, "Invalid credentials or inactive account")
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/password/forgot", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        for key in ("otp_user_id", "otp_username", "otp_channel", "otp_verified_user_id", "otp_demo_code"):
            session.pop(key, None)
        username = request.form.get("username", "").strip().lower()
        channel = request.form.get("channel", "email")
        contact = request.form.get("contact", "").strip()
        generic = "If the account and registered contact match, a reset code will be sent."
        if channel not in ("email", "sms"):
            flash(generic, "success"); return render_template("forgot_password.html")
        db = get_db()
        field = "email" if channel == "email" else "phone"
        user = db.execute(f"SELECT id,username,{field} AS contact FROM users WHERE username=? AND is_active=1", (username,)).fetchone()
        # Require exact registered contact match; don't reveal whether an account exists.
        if user and user["contact"] and contact and user["contact"].strip().lower() == contact.strip().lower():
            now = datetime.now(); now_s = now.strftime("%Y-%m-%d %H:%M:%S")
            recent = db.execute("SELECT COUNT(*) FROM password_otps WHERE user_id=? AND created_at>=?",
                (user["id"], (now-timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S"))).fetchone()[0]
            if recent < 3:
                code = f"{secrets.randbelow(1000000):06d}"
                db.execute("UPDATE password_otps SET used=1 WHERE user_id=? AND used=0", (user["id"],))
                db.execute("INSERT INTO password_otps(user_id,channel,destination,otp_hash,expires_at,created_at) VALUES(?,?,?,?,?,?)",
                    (user["id"], channel, mask_destination(user["contact"], channel), otp_digest(code,user["id"]),
                     (now+timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S"), now_s))
                db.commit()
                try:
                    sent, demo = deliver_otp(channel, user["contact"], code)
                    session["otp_user_id"] = user["id"]
                    session["otp_username"] = user["username"]
                    session["otp_channel"] = channel
                    session["otp_demo_code"] = code if demo else None
                    log_audit("password_otp_requested", username, f"Channel={channel}; destination={mask_destination(user['contact'],channel)}")
                    flash("Demo OTP: " + code if demo else generic, "success")
                    return redirect(url_for("verify_otp"))
                except Exception as exc:
                    app.logger.error("OTP delivery failed: %s", exc)
                    log_audit("password_otp_delivery_failed", username, f"Channel={channel}")
            else:
                log_audit("password_otp_rate_limited", username, "OTP request limit reached")
        flash(generic, "success")
    return render_template("forgot_password.html")

@app.route("/password/verify", methods=["GET", "POST"])
def verify_otp():
    user_id = session.get("otp_user_id")
    if not user_id: return redirect(url_for("forgot_password"))
    if request.method == "POST":
        code = request.form.get("otp", "").strip()
        db = get_db(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = db.execute("SELECT * FROM password_otps WHERE user_id=? AND used=0 ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
        if not row or row["expires_at"] < now or row["attempts"] >= 5:
            flash("Code expired or attempt limit reached. Request a new code.", "error")
        elif secrets.compare_digest(row["otp_hash"], otp_digest(code, user_id)):
            db.execute("UPDATE password_otps SET used=1 WHERE id=?", (row["id"],)); db.commit()
            session["otp_verified_user_id"] = user_id
            session.pop("otp_demo_code", None)
            log_audit("password_otp_verified", session.get("otp_username", ""), "OTP verified")
            return redirect(url_for("reset_password"))
        else:
            db.execute("UPDATE password_otps SET attempts=attempts+1 WHERE id=?", (row["id"],)); db.commit()
            log_audit("password_otp_failed", session.get("otp_username", ""), "Incorrect OTP")
            flash("Incorrect code. Try again.", "error")
    return render_template("verify_otp.html", channel=session.get("otp_channel", "email"))

@app.route("/password/reset", methods=["GET", "POST"])
def reset_password():
    user_id = session.get("otp_verified_user_id")
    if not user_id: return redirect(url_for("forgot_password"))
    if request.method == "POST":
        new = request.form.get("new_password", ""); confirm = request.form.get("confirm_password", "")
        if len(new) < 10: flash("Password must be at least 10 characters.", "error")
        elif new != confirm: flash("Passwords do not match.", "error")
        else:
            db = get_db(); user = db.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), user_id)); db.commit()
            log_audit("password_reset_otp", user["username"] if user else "", "Password reset with verified OTP")
            for key in ("otp_user_id", "otp_username", "otp_channel", "otp_verified_user_id", "otp_demo_code"):
                session.pop(key, None)
            flash("Password reset complete. Please log in with your new password.", "success")
            return redirect(url_for("login"))
    return render_template("reset_password.html")

@app.route("/logout", methods=["POST"])
def logout():
    if session.get("user_id"):
        log_audit("logout", session.get("username", ""), "User logged out")
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required()
def dashboard():
    role = session.get("role")
    db = get_db()
    if role == "officer":
        stats = {"pending": db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0],
                 "products": db.execute("SELECT COUNT(*) FROM stock").fetchone()[0]}
        recent = db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 6").fetchall()
        chart_status = db.execute("SELECT status,COUNT(*) total FROM requests GROUP BY status ORDER BY status").fetchall()
        chart_stock = db.execute("SELECT product,quantity,threshold FROM stock ORDER BY product").fetchall()
        alerts = db.execute("SELECT * FROM low_stock_alerts WHERE active=1 ORDER BY quantity,product").fetchall()
        return render_template("officer_dashboard.html", stats=stats, recent=recent, chart_status=chart_status, chart_stock=chart_stock, alerts=alerts)
    if role == "admin":
        stats = {"users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                 "farmers": db.execute("SELECT COUNT(*) FROM users WHERE role='farmer'").fetchone()[0],
                 "officers": db.execute("SELECT COUNT(*) FROM users WHERE role='officer'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0]}
        users = db.execute("SELECT username,display_name,role FROM users ORDER BY role,username").fetchall()
        chart_status = db.execute("SELECT status,COUNT(*) total FROM requests GROUP BY status ORDER BY status").fetchall()
        chart_stock = db.execute("SELECT product,quantity,threshold FROM stock ORDER BY product").fetchall()
        alerts = db.execute("SELECT * FROM low_stock_alerts WHERE active=1 ORDER BY quantity,product").fetchall()
        return render_template("admin_dashboard.html", stats=stats, users=users, chart_status=chart_status, chart_stock=chart_stock, alerts=alerts)
    # Farmer sees only requests associated with their demo account phone.
    rows = db.execute("SELECT * FROM requests WHERE phone=? ORDER BY id DESC", (session.get("phone", ""),)).fetchall()
    stock = db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    return render_template("farmer_dashboard.html", rows=rows, stock=stock)

@app.route("/admin/users", methods=["GET", "POST"])
@login_required("admin")
def admin_users():
    db = get_db()
    if request.method == "POST":
        action = request.form.get("action", "create")
        if action == "create":
            username = request.form.get("username", "").strip().lower()
            display_name = request.form.get("display_name", "").strip()
            phone = request.form.get("phone", "").strip()
            email = request.form.get("email", "").strip().lower()
            role = request.form.get("role", "")
            password = request.form.get("password", "")
            if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
                flash("Username must be 3–32 characters: letters, numbers, dot, underscore or hyphen.", "error")
            elif not display_name or role not in ("farmer", "officer", "admin"):
                flash("Enter a display name and valid role.", "error")
            elif len(password) < 10:
                flash("Initial password must be at least 10 characters.", "error")
            else:
                try:
                    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cur = db.execute("INSERT INTO users(username,password_hash,role,display_name,phone,email,created_at) VALUES(?,?,?,?,?,?,?)",
                                     (username, generate_password_hash(password), role, display_name, phone, email, now))
                    db.commit(); log_audit("user_created", username, f"Created {role} account (id={cur.lastrowid})")
                    flash(f"Account '{username}' created. Share the initial password securely.", "success")
                    return redirect(url_for("admin_users"))
                except sqlite3.IntegrityError:
                    db.rollback(); flash("That username already exists.", "error")
        elif action == "toggle":
            try: target_id = int(request.form.get("user_id", "0"))
            except ValueError: target_id = 0
            target = db.execute("SELECT id,username,role,is_active FROM users WHERE id=?", (target_id,)).fetchone()
            if not target: flash("Account not found.", "error")
            elif target["id"] == session.get("user_id"): flash("You cannot disable your own account.", "error")
            elif target["role"] == "admin" and target["is_active"] and db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1").fetchone()[0] <= 1:
                flash("Cannot disable the last active admin account.", "error")
            else:
                active = 0 if target["is_active"] else 1
                db.execute("UPDATE users SET is_active=? WHERE id=?", (active, target_id)); db.commit()
                log_audit("user_disabled" if not active else "user_enabled", target["username"], "Account status changed by admin")
                flash(f"Account '{target['username']}' {'disabled' if not active else 'enabled'}.", "success")
                return redirect(url_for("admin_users"))
        elif action == "reset_password":
            try: target_id = int(request.form.get("user_id", "0"))
            except ValueError: target_id = 0
            password = request.form.get("new_password", "")
            target = db.execute("SELECT id,username FROM users WHERE id=?", (target_id,)).fetchone()
            if not target: flash("Account not found.", "error")
            elif len(password) < 10: flash("New password must be at least 10 characters.", "error")
            else:
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), target_id)); db.commit()
                log_audit("admin_password_reset", target["username"], "Password reset by administrator")
                flash(f"Password reset for '{target['username']}'. Tell the user securely.", "success")
                return redirect(url_for("admin_users"))
    users = db.execute("SELECT id,username,display_name,role,phone,email,is_active,created_at FROM users ORDER BY role,username").fetchall()
    return render_template("admin_users.html", users=users)

@app.route("/account/password", methods=["GET", "POST"])
@login_required()
def change_password():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        user = get_db().execute("SELECT password_hash FROM users WHERE id=?", (session["user_id"],)).fetchone()
        if not user or not check_password_hash(user["password_hash"], current): flash("Current password is incorrect.", "error")
        elif len(new) < 10: flash("New password must be at least 10 characters.", "error")
        elif new != confirm: flash("New passwords do not match.", "error")
        elif check_password_hash(user["password_hash"], new): flash("Choose a password different from your current password.", "error")
        else:
            db = get_db(); db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), session["user_id"]))
            db.commit(); log_audit("password_changed", session.get("username", ""), "User changed own password")
            flash("Password changed successfully.", "success"); return redirect(url_for("dashboard"))
    return render_template("change_password.html")

@app.route("/admin/audit")
@login_required("admin")
def audit_logs():
    db = get_db(); action = request.args.get("action", "").strip()[:100]
    username = request.args.get("username", "").strip()[:100]
    start = request.args.get("start", "").strip(); end = request.args.get("end", "").strip()
    sql = "SELECT * FROM audit_logs WHERE 1=1"; args = []
    if action: sql += " AND action LIKE ?"; args.append("%" + action + "%")
    if username: sql += " AND (actor_username LIKE ? OR target LIKE ?)"; args += ["%"+username+"%", "%"+username+"%"]
    if start and re.fullmatch(r"\d{4}-\d{2}-\d{2}", start): sql += " AND date(created_at)>=date(?)"; args.append(start)
    if end and re.fullmatch(r"\d{4}-\d{2}-\d{2}", end): sql += " AND date(created_at)<=date(?)"; args.append(end)
    rows = db.execute(sql + " ORDER BY id DESC LIMIT 500", args).fetchall()
    return render_template("audit_logs.html", rows=rows, action=action, username=username, start=start, end=end)

@app.route("/admin/reports")
@login_required("admin")
def user_activity_reports():
    db = get_db()
    days_raw = request.args.get("days", "30")
    days = int(days_raw) if days_raw in ("7", "30", "90") else 30
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    summary = db.execute("""SELECT action, COUNT(*) AS total FROM audit_logs
        WHERE created_at >= ? GROUP BY action ORDER BY total DESC, action""", (since,)).fetchall()
    people = db.execute("""SELECT actor_username, actor_role,
        SUM(CASE WHEN action='login_success' THEN 1 ELSE 0 END) AS successful_logins,
        SUM(CASE WHEN action='login_failed' THEN 1 ELSE 0 END) AS failed_logins,
        COUNT(*) AS events, MAX(created_at) AS last_activity
        FROM audit_logs WHERE created_at >= ? AND actor_username IS NOT NULL
        GROUP BY actor_username, actor_role ORDER BY events DESC, actor_username""", (since,)).fetchall()
    return render_template("activity_reports.html", days=days, summary=summary, people=people)

@app.route("/admin/audit/export.csv")
@login_required("admin")
def export_audit_csv():
    db=get_db(); action=request.args.get("action","").strip()[:100]; username=request.args.get("username","").strip()[:100]
    start=request.args.get("start","").strip(); end=request.args.get("end","").strip()
    sql="SELECT id,actor_username,actor_role,action,target,details,ip_address,created_at FROM audit_logs WHERE 1=1"; args=[]
    if action: sql+=" AND action LIKE ?"; args.append("%"+action+"%")
    if username: sql+=" AND (actor_username LIKE ? OR target LIKE ?)"; args += ["%"+username+"%","%"+username+"%"]
    if start and re.fullmatch(r"\d{4}-\d{2}-\d{2}",start): sql+=" AND date(created_at)>=date(?)"; args.append(start)
    if end and re.fullmatch(r"\d{4}-\d{2}-\d{2}",end): sql+=" AND date(created_at)<=date(?)"; args.append(end)
    rows=db.execute(sql+" ORDER BY id DESC LIMIT 10000",args).fetchall()
    out=io.StringIO(); w=csv.writer(out); w.writerow(rows[0].keys() if rows else ["id","actor_username","actor_role","action","target","details","ip_address","created_at"])
    for row in rows: w.writerow([row[k] for k in row.keys()])
    from flask import Response
    log_audit("audit_export_csv", "audit_logs", f"Exported {len(rows)} rows")
    return Response('\ufeff'+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":"attachment; filename=vivasayi_audit_log.csv"})

@app.route("/admin/reports/export/<kind>")
@login_required("officer", "admin")
def export_report(kind):
    if kind not in ("csv","xlsx"): abort(404)
    db=get_db()
    report=request.args.get("report","requests")
    if report=="inventory":
        if session.get("role") != "admin": abort(403)
        headers=["product","tamil_name","category","unit","quantity","threshold","updated_at"]
        rows=db.execute("SELECT product,tamil_name,category,unit,quantity,threshold,updated_at FROM stock ORDER BY product").fetchall()
    else:
        report="requests"; headers=["id","farmer_name","phone","village","society","product","quantity","unit","notes","status","created_at"]
        rows=db.execute("SELECT id,farmer_name,phone,village,society,product,quantity,unit,notes,status,created_at FROM requests ORDER BY id DESC").fetchall()
    if kind=="csv":
        out=io.StringIO(); w=csv.writer(out); w.writerow(headers)
        for row in rows: w.writerow([row[h] for h in headers])
        from flask import Response
        response=Response('\ufeff'+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":f"attachment; filename=vivasayi_{report}.csv"})
    else:
        try: from openpyxl import Workbook
        except ImportError: abort(503, description="Excel export requires openpyxl. Install requirements.txt and retry.")
        wb=Workbook(); ws=wb.active; ws.title=report.title(); ws.append(headers)
        for row in rows: ws.append([row[h] for h in headers])
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        for col in ws.columns:
            letter=col[0].column_letter; ws.column_dimensions[letter].width=min(max(max(len(str(c.value or "")) for c in col)+2,12),36)
        data=io.BytesIO(); wb.save(data); data.seek(0)
        from flask import Response
        response=Response(data.getvalue(),mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":f"attachment; filename=vivasayi_{report}.xlsx"})
    log_audit("report_export", report, f"Format={kind}; rows={len(rows)}")
    return response

@app.errorhandler(403)
def forbidden(_):
    return render_template("403.html"), 403

@app.route("/health")
def health(): return {"status":"ok","app":"Vivasayi Connect TN V2.5"}

@app.errorhandler(404)
def not_found(_): return render_template("404.html"),404

if __name__=="__main__": app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")

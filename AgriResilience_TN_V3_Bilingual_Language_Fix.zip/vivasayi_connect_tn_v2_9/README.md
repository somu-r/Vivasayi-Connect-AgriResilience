# Vivasayi Connect TN — Operations build

Flask + SQLite application for cooperative inventory, farmer supply requests, role-based dashboards, user administration, audit reporting, OTP sign-in/password recovery, low-stock notifications and SMS announcements. The app no longer inserts sample users, sample inventory or welcome/demo announcements into a fresh database. Screens show records entered by your organization.

## 1. Install and run on Windows

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Create a first administrator before the first run. In the same CMD window, set a unique username and a long password (at least 12 characters):

```bat
set BOOTSTRAP_ADMIN_USERNAME=your_admin_username
set BOOTSTRAP_ADMIN_PASSWORD=use_a_long_unique_password_here
set BOOTSTRAP_ADMIN_NAME=System Administrator
set SECRET_KEY=replace_with_a_long_random_secret
set OTP_SECRET=replace_with_a_different_long_random_secret
python app.py
```

Then open `http://127.0.0.1:5000`, log in with the bootstrap administrator, and create officer accounts from **User management**. Public registration creates farmer accounts only. The bootstrap administrator is created only if no administrator exists and valid bootstrap environment variables are supplied. Do not use example values as real passwords.

## 2. Set up real organizational data

1. Log in as an administrator and create officer accounts.
2. Open **Inventory** as an officer/admin. Add each product with its local/Tamil name, category, unit, opening balance and low-stock threshold. Enter actual stock counts from the cooperative ledger.
3. Record all incoming and outgoing stock movements in the same page so quantities and movement history stay in sync.
4. Farmers can register and submit requests. Use a registered mobile number consistently to associate requests with the farmer account.
5. Add verified phone/email contacts to accounts before enabling external notifications.

The database starts empty intentionally. This avoids fake inventory and fake recipient numbers being mistaken for real records. Existing database files are not automatically erased; back up before upgrading.

## 3. SMS and email configuration

### Twilio SMS

Set these in the same Windows CMD session before starting the app:

```bat
set TWILIO_ACCOUNT_SID=your_account_sid
set TWILIO_AUTH_TOKEN=your_rotated_auth_token
set TWILIO_FROM=+1xxxxxxxxxx
```

Use the actual SMS-capable sender number assigned to your Twilio account. Registered recipient numbers should use E.164 format, e.g. `+919876543210`. Check Twilio's supported destination countries, trial restrictions, message logs, delivery status and charges. Rotate any token that has been exposed. Never paste credentials into chat or commit them to source control.

### Email announcements (Gmail example)

The Announcements page can send Tamil UTF-8 email to the selected audience's registered email addresses. For Gmail, enable 2-Step Verification and create a Google **App Password** (do not use your normal Gmail password). Keep the App Password private; do not paste it into chat or commit it to source control.

In the same Windows CMD window that starts Flask, configure:

```bat
set SMTP_HOST=smtp.gmail.com
set SMTP_PORT=587
set SMTP_FROM=somukmk@gmail.com
set SMTP_USER=somukmk@gmail.com
set SMTP_PASSWORD=PASTE_YOUR_GOOGLE_APP_PASSWORD_HERE
python app.py
```

Replace the placeholder locally with the App Password generated in your Google account. The sender address must belong to the account you authenticate with. These settings apply only to that CMD session; for persistent setup, use a secure local environment configuration that is excluded from ZIPs/source control. The app attempts sending when the officer/admin submits the announcement form. It records each attempt as sent only when the SMTP server accepts it; this does not guarantee inbox delivery. Users without a registered email are recorded as failed. Use the announcement delivery log/database to investigate failures. Never send unsolicited mail; select the intended audience and use only legitimate registered recipients.

## 4. What is live and what still needs external setup?

- Dashboards, user management, requests, inventory, stock movements, reports and audit logs use the application's database.
- Low-stock notifications and announcement SMS attempt real provider sends only when Twilio/SMTP is configured. Provider acceptance does not guarantee final delivery; check provider logs.
- The IVR page is a database-backed on-screen enquiry assistant, **not a live telephone call**. Live voice IVR still requires a public HTTPS deployment, Twilio Voice number, voice webhook/TwiML flow, call status/error handling, consent and real-call testing.
- This is not yet a fully audited production service. Before public launch, add/verify CSRF protection, rate limiting, secure secret management, HTTPS, backups/restore tests, monitoring, data retention/privacy policy, access review and a security assessment. Use a production WSGI server (e.g. Gunicorn) rather than Flask's development server.

## 5. Environment notes

- `DATABASE_PATH` can point to a persistent SQLite file. For multiple concurrent production workers or larger deployments, migrate to PostgreSQL.
- `APP_ENV=production` disables local OTP fallback disclosure; configure real delivery first.
- Set a strong, unique `SECRET_KEY` and a different `OTP_SECRET` outside source control.
- Existing demo accounts/rows in a database from an earlier version are not deleted automatically. Disable/remove those records manually after confirming they are not real accounts.

## AgriResilience TN V3 — Cooperative Society Finder

The V3 module adds `/societies` for logged-in farmers, officers and administrators. It supports village/society/block text search, district filters, PIN-code prefix search, and optional browser GPS search with a configurable 5–100 km radius. GPS coordinates are used only in the request and are not stored. Distances are straight-line estimates; they are not driving distances. Records without coordinates are omitted from GPS radius results rather than being assigned invented distances.

### Load an authorized directory

An administrator can open **Society directory import** in the navigation, or visit `/admin/societies/import`, and upload a CSV (maximum 5 MB). A sample schema is available at `/static/society_directory_template.csv`. Required column: `name` (also accepts `society_name` or `paccs_name`). Optional columns: `society_code`, `district`, `block`, `village`, `pincode`, `address`, `phone`, `email`, `latitude`, `longitude`, `services`, `source_name`, `source_url`, `verified_at`, `data_status`.

The importer records import history, updates likely duplicates using society code/district or name/district/village, ignores invalid coordinates, and only allows `http(s)` source links. Records default to `Unverified`. A row marked `Verified` needs both a verification date and a source name or URL; otherwise it is downgraded to `Needs review`. Import only public/authorized directory data. The included CSV is a clearly labelled demo template, not a real PACCS directory.

### Coverage and operational notes

The finder intentionally does not scrape external sites or claim live/statewide completeness. Populate it with a permitted official directory, confirm contact information and coordinates, and record sources and verification dates. `Directory records` and `Marked verified` counters report local database values only; they do not establish statewide coverage. Use HTTPS in deployment because GPS browser permissions generally require a secure context (localhost is also supported).

### V3 database tables

- `cooperative_societies`: society metadata, contact details, coordinates, source and verification state.
- `society_directory_imports`: admin import audit/history and row counts.

Existing tables and roles are preserved; schema creation is additive via the app's existing `init_db()` bootstrap.


## Simplified V3 navigation

The top navigation and dashboard shortcut buttons hide the optional IVR, announcements, inventory, farmer-request/request-management, and change-password links to keep the interface focused on Dashboard and Society Finder. Existing route handlers and database tables are retained to avoid deleting existing data or breaking dependencies. Password management remains available through the existing secure account flow; do not remove password security controls.

## AgriResilience TN V3 prototype modules

- Open **GIS & Crop Advisory** after signing in as an officer or administrator (`/resilience`).
- The map and stock values are explicitly fictional demonstration data, isolated from the operational `stock` table.
- Matching requires the same input type and unit, sufficient quantity, verified flag, non-expired validity date, and same district. Straight-line distance is displayed when demand coordinates are supplied.
- Matching creates pending review proposals only. Officer decisions are timestamped and written to a decision-history table and audit log. No transfer, reservation, or stock adjustment is performed.
- Advisory entries are marked `Illustrative sample` by default. To mark an entry as `Official source verified`, the form requires an HTTPS source URL and a non-placeholder source name. Staff must independently verify that the source is official, applicable to the district/season/crop, and current.
- Fictional seed rows use clearly labelled demo PACCS names and coordinates. Do not present these as real societies or live stock.

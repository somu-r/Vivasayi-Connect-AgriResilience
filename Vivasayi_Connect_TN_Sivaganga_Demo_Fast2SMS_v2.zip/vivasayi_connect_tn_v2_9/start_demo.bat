@echo off
cd /d "%~dp0"
if not exist ".env" (
  echo .env file not found. Copy .env.example to .env first.
  pause
  exit /b 1
)
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed. Check Python and internet connection.
  pause
  exit /b 1
)
py app.py
pause

# Vivasayi Connect TN V2.8

Bilingual English/Tamil Flask + SQLite prototype for farmer requests, stock coordination, role-based dashboards, account management and audit reporting.

## V2.6 additions
- Password reset using six-digit OTP by registered email or phone. OTP expires after 10 minutes; maximum five attempts per code; requests are limited to three per account per 15 minutes.
- SMTP email delivery and Twilio SMS delivery are supported when environment variables are configured.
- User activity reports for 7, 30, or 90 days, with per-action and per-user aggregates.
- Audit log filters for action, username/target, and date range; up to 500 matches displayed.
- User email field is migrated automatically for existing V2.2 databases.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate  | macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. Demo credentials on a fresh database: `admin/admin123`, `officer/officer123`, `farmer/farmer123`. Change these immediately. Add a registered email or phone to the user record to use password recovery.

## Email OTP configuration
Set `SMTP_HOST`, `SMTP_PORT` (usually 587), `SMTP_FROM`, and optionally `SMTP_USER` and `SMTP_PASSWORD`. SMTP STARTTLS is used.

## SMS OTP configuration
Set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM` (a Twilio SMS-capable number). Store credentials as environment secrets; never commit them. Use phone numbers in E.164 format (e.g. +91...). SMS provider charges and regulatory requirements may apply.

## Security configuration
Set a long random `SECRET_KEY`, and set a separate random `OTP_SECRET`. Set `APP_ENV=production` to disable demo OTP disclosure. If neither provider is configured in production, OTP delivery fails closed. Configure HTTPS, secure session cookies, CSRF protection, login/OTP rate limiting at application or reverse-proxy level, monitoring, backups, and data-retention policy before public deployment. Audit logs include IP addresses and must be protected as personal data.

## Existing database migration
The app adds the `email` field and OTP table when an existing V2.2 database is opened. Back up your database before upgrading.

## Limitations
This is a prototype and has not undergone a security review. OTP messages require valid SMTP/Twilio configuration for real delivery. Demo OTP may be visible in local development only. Inventory is sample data; announcements and IVR remain simulated.


## V2.6 account registration and login UI
- Added public `/register` farmer registration with name, mobile, email, username, password and confirmation.
- Public registration can only create the `farmer` role; officer/admin accounts remain admin-managed.
- Removed visible demo usernames/passwords from the login screen and refreshed the responsive login UI.
- Registration validates username format, email, phone length, password length, confirmation, and duplicate username/email/mobile.
- Real email/SMS OTP still requires configured SMTP/Twilio credentials; registration does not yet send a verification OTP.


## V2.6 additions
- Dashboard analytics: request status and stock-level bar visualizations.
- Admin/officer CSV and Excel exports for request reports; admin exports inventory reports in CSV/Excel.
- Admin audit log can be exported as CSV with filters applied.
- Automatic in-app low-stock alerts are maintained for products at or below configured threshold and shown on admin/officer dashboards. These are in-app alerts, not external SMS/email notifications.
- Excel exports use `openpyxl`, installed through `requirements.txt`.

## V2.6 automatic low-stock SMS/email notifications
When an officer/admin records a stock movement that takes a product from above its threshold to at/below threshold, the app sends an alert to active officer/admin accounts that have a registered email/phone and a configured provider. It sends once per crossing (not on every page view); adding stock above threshold and crossing low again can trigger a new alert. Delivery attempts and failures are stored in `low_stock_notifications`.

Configure SMTP for email (`SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM`, optional `SMTP_USER`, `SMTP_PASSWORD`) and Twilio for SMS (`TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`). Save recipients' real email addresses and phone numbers in the admin user-management page; SMS phone numbers must be E.164 format, such as `+919876543210`. Twilio must be enabled for the destination and region, and charges may apply. If a provider is missing or a delivery fails, the app logs the failure instead of claiming the message was sent. This is event-triggered on inventory updates, not a background scheduler.


## V2.7: Login with mobile/email OTP
- The login page includes a link to sign in with a registered email address or mobile number using a six-digit OTP.
- Codes expire in 10 minutes, allow up to five verification attempts, and use the existing per-user limit of three OTP requests per 15 minutes.
- Configure SMTP variables for email or Twilio variables for SMS. In development only, the demo code is shown in the UI/log; production mode fails closed when delivery is not configured.
- This adds an OTP sign-in option; the existing username/password login remains available.

## V2.8: Real-time announcement SMS
- Officer/admin announcements now trigger SMS sends to active users in the selected audience: all farmers, all officers/admins, or all registered users.
- Each recipient attempt is recorded in `announcement_deliveries` with sent/failed status and a masked phone number. Audit logs record the announcement send summary.
- Configure `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM` before sending. Use international phone format (e.g. `+919876543210`), an SMS-enabled Twilio sender, and destinations allowed by your Twilio account. Provider acceptance is not proof of final handset delivery; check message status in Twilio Console.
- Announcement SMS is sent immediately when an authorized officer/admin submits the form. Messages may incur charges. Obtain appropriate consent and follow applicable messaging rules; test with a small audience first. Existing demo phone numbers are not valid recipient numbers.

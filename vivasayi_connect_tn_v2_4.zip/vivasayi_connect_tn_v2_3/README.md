# Vivasayi Connect TN V2.3

Bilingual English/Tamil Flask + SQLite prototype for farmer requests, stock coordination, role-based dashboards, account management and audit reporting.

## V2.3 additions
- Password reset using six-digit OTP by registered email or phone. OTP expires after 10 minutes; maximum five attempts per code; requests are limited to three per account per 15 minutes.
- SMTP email delivery and Twilio SMS delivery are supported when environment variables are configured.
- User activity reports for 7, 30, or 90 days, with per-action and per-user aggregates.
- Audit log filters for action, username/target, and date range; up to 500 matches displayed.
- User email field is migrated automatically for existing V2.2 databases.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate  | macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. Demo credentials on a fresh database: `admin/admin123`, `officer/officer123`, `farmer/farmer123`. Change these immediately. Add a registered email or phone to the user record to use password recovery.

## Email OTP configuration
Set `SMTP_HOST`, `SMTP_PORT` (usually 587), `SMTP_FROM`, and optionally `SMTP_USER` and `SMTP_PASSWORD`. SMTP STARTTLS is used.

## SMS OTP configuration
Set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM` (a Twilio SMS-capable number). Store credentials as environment secrets; never commit them. Use phone numbers in E.164 format (e.g. +91...). SMS provider charges and regulatory requirements may apply.

## Security configuration
Set a long random `SECRET_KEY`, and set a separate random `OTP_SECRET`. Set `APP_ENV=production` to disable demo OTP disclosure. If neither provider is configured in production, OTP delivery fails closed. Configure HTTPS, secure session cookies, CSRF protection, login/OTP rate limiting at application or reverse-proxy level, monitoring, backups, and data-retention policy before public deployment. Audit logs include IP addresses and must be protected as personal data.

## Existing database migration
The app adds the `email` field and OTP table when an existing V2.2 database is opened. Back up your database before upgrading.

## Limitations
This is a prototype and has not undergone a security review. OTP messages require valid SMTP/Twilio configuration for real delivery. Demo OTP may be visible in local development only. Inventory is sample data; announcements and IVR remain simulated.


## V2.4 account registration and login UI
- Added public `/register` farmer registration with name, mobile, email, username, password and confirmation.
- Public registration can only create the `farmer` role; officer/admin accounts remain admin-managed.
- Removed visible demo usernames/passwords from the login screen and refreshed the responsive login UI.
- Registration validates username format, email, phone length, password length, confirmation, and duplicate username/email/mobile.
- Real email/SMS OTP still requires configured SMTP/Twilio credentials; registration does not yet send a verification OTP.

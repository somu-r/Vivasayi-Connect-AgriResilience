import os, sqlite3, re, secrets, hashlib, smtplib, ssl, urllib.parse, urllib.request, json, csv, io, math
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
APP_ENV = os.environ.get("APP_ENV", "development").lower()
if APP_ENV == "production" and not os.environ.get("SECRET_KEY"):
    raise RuntimeError("SECRET_KEY must be configured in production")
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=(APP_ENV == "production"),
)
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(app.root_path, "vivasayi_v2.db"))

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None: db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('farmer','officer','admin')),
      display_name TEXT NOT NULL, phone TEXT, email TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS password_otps (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, channel TEXT NOT NULL,
      destination TEXT NOT NULL, otp_hash TEXT NOT NULL, expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0, used INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, actor_username TEXT, actor_role TEXT,
      action TEXT NOT NULL, target TEXT, details TEXT, ip_address TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT UNIQUE NOT NULL,
      tamil_name TEXT NOT NULL, category TEXT NOT NULL, tamil_category TEXT NOT NULL,
      unit TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, threshold REAL NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_name TEXT NOT NULL, phone TEXT,
      village TEXT NOT NULL, society TEXT NOT NULL, product TEXT NOT NULL,
      quantity REAL NOT NULL, unit TEXT NOT NULL, notes TEXT, status TEXT NOT NULL DEFAULT 'Pending',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      audience TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS low_stock_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL UNIQUE, quantity REAL NOT NULL,
      threshold REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_moves (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, move_type TEXT NOT NULL,
      quantity REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS low_stock_notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT NOT NULL, recipient TEXT NOT NULL,
      channel TEXT NOT NULL, status TEXT NOT NULL, error TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcement_deliveries (
      id INTEGER PRIMARY KEY AUTOINCREMENT, announcement_id INTEGER NOT NULL,
      recipient_user_id INTEGER, recipient TEXT NOT NULL, channel TEXT NOT NULL DEFAULT 'sms',
      status TEXT NOT NULL, error TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cooperative_societies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      society_code TEXT NOT NULL DEFAULT '', name TEXT NOT NULL,
      district TEXT NOT NULL DEFAULT '', block TEXT NOT NULL DEFAULT '', village TEXT NOT NULL DEFAULT '',
      pincode TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '', latitude REAL, longitude REAL,
      services TEXT NOT NULL DEFAULT '', source_name TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
      verified_at TEXT NOT NULL DEFAULT '', data_status TEXT NOT NULL DEFAULT 'Unverified',
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_society_district ON cooperative_societies(district);
    CREATE INDEX IF NOT EXISTS idx_society_village ON cooperative_societies(village);
    CREATE TABLE IF NOT EXISTS society_directory_imports (
      id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, imported_by TEXT NOT NULL,
      rows_seen INTEGER NOT NULL DEFAULT 0, rows_added INTEGER NOT NULL DEFAULT 0,
      rows_updated INTEGER NOT NULL DEFAULT 0, rows_skipped INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS demo_paccs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, district TEXT NOT NULL,
      village TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL,
      fictional INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS demo_stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT, paccs_id INTEGER NOT NULL, input_type TEXT NOT NULL,
      quantity REAL NOT NULL, unit TEXT NOT NULL, verified INTEGER NOT NULL DEFAULT 0,
      valid_until TEXT NOT NULL, updated_at TEXT NOT NULL,
      FOREIGN KEY(paccs_id) REFERENCES demo_paccs(id)
    );
    CREATE TABLE IF NOT EXISTS input_demands (
      id INTEGER PRIMARY KEY AUTOINCREMENT, requester TEXT NOT NULL, village TEXT NOT NULL,
      district TEXT NOT NULL, input_type TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL,
      latitude REAL, longitude REAL, created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending'
    );
    CREATE TABLE IF NOT EXISTS crop_advisories (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, district TEXT NOT NULL,
      season TEXT NOT NULL, crop TEXT NOT NULL, advice TEXT NOT NULL, source_name TEXT NOT NULL,
      source_url TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Illustrative sample'
    );
    CREATE TABLE IF NOT EXISTS redistribution_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT, demand_id INTEGER NOT NULL, stock_id INTEGER NOT NULL,
      match_reasons TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending',
      officer_decision TEXT NOT NULL DEFAULT '', decision_by TEXT NOT NULL DEFAULT '',
      decision_at TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
      FOREIGN KEY(demand_id) REFERENCES input_demands(id), FOREIGN KEY(stock_id) REFERENCES demo_stock(id)
    );
    CREATE TABLE IF NOT EXISTS redistribution_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT, review_id INTEGER NOT NULL, old_status TEXT NOT NULL,
      new_status TEXT NOT NULL, decision TEXT NOT NULL, actor TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL, FOREIGN KEY(review_id) REFERENCES redistribution_reviews(id)
    );
    """)
    # Migrate existing V2.1 databases safely.
    user_cols = {row[1] for row in db.execute("PRAGMA table_info(users)").fetchall()}
    if "is_active" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
    if "created_at" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN created_at TEXT NOT NULL DEFAULT ''")
    if "email" not in user_cols:
        db.execute("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''")
    # Clearly fictional demonstration records for the GIS/matching prototype only.
    # They are isolated from the operational stock table and never represent real PACCS data.
    if db.execute("SELECT COUNT(*) FROM demo_paccs").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        demo_sites = [
          ("DEMO PACCS Melur (Fictional)", "Madurai", "Demo Melur", 10.032, 78.339),
          ("DEMO PACCS Vadipatti (Fictional)", "Madurai", "Demo Vadipatti", 10.084, 77.962),
          ("DEMO PACCS Dindigul (Fictional)", "Dindigul", "Demo Dindigul", 10.367, 77.980),
          ("DEMO PACCS Thanjavur (Fictional)", "Thanjavur", "Demo Thanjavur", 10.787, 79.137),
        ]
        for site in demo_sites:
            db.execute("INSERT INTO demo_paccs(name,district,village,latitude,longitude,fictional) VALUES(?,?,?,?,?,1)", site)
        ids = [r[0] for r in db.execute("SELECT id FROM demo_paccs ORDER BY id").fetchall()]
        samples = [(ids[0],"Urea",120,"bags",1,"2099-12-31"),(ids[0],"Paddy seed",40,"bags",1,"2099-12-31"),
                   (ids[1],"Urea",25,"bags",1,"2099-12-31"),(ids[1],"DAP",70,"bags",1,"2099-12-31"),
                   (ids[2],"Paddy seed",100,"bags",0,"2099-12-31"),(ids[2],"DAP",30,"bags",1,"2020-01-01"),
                   (ids[3],"Urea",200,"bags",1,"2099-12-31")]
        for site_id, typ, qty, unit, verified, expiry in samples:
            db.execute("INSERT INTO demo_stock(paccs_id,input_type,quantity,unit,verified,valid_until,updated_at) VALUES(?,?,?,?,?,?,?)", (site_id,typ,qty,unit,verified,expiry,now))
        db.execute("INSERT INTO crop_advisories(title,district,season,crop,advice,source_name,source_url,updated_at,status) VALUES(?,?,?,?,?,?,?,?,?)",
                   ("Illustrative paddy advisory", "Madurai", "Example season", "Paddy", "SAMPLE ONLY: Replace this text with current, verified official advice before use. This is not an agricultural recommendation.", "Illustrative placeholder — not an official source", "", now, "Illustrative sample"))
    # Production-oriented bootstrap: never create demo users, stock or announcements.
    # An initial administrator is created only when explicit environment variables are set.
    admin_username = os.environ.get("BOOTSTRAP_ADMIN_USERNAME", "").strip().lower()
    admin_password = os.environ.get("BOOTSTRAP_ADMIN_PASSWORD", "")
    admin_name = os.environ.get("BOOTSTRAP_ADMIN_NAME", "System Administrator").strip()
    if admin_username and admin_password and db.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0] == 0:
        if re.fullmatch(r"[a-z0-9_.-]{3,32}", admin_username) and len(admin_password) >= 12:
            created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            db.execute("INSERT OR IGNORE INTO users(username,password_hash,role,display_name,created_at) VALUES(?,?,?,?,?)",
                       (admin_username, generate_password_hash(admin_password), "admin", admin_name or "System Administrator", created))
    db.commit(); db.close()

@app.before_request
def before():
    init_db()
    session.setdefault("lang","en")
    # Maintain an in-app alert for every item currently at/below its threshold.
    try:
        db = sqlite3.connect(DB_PATH)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        low = db.execute("SELECT product,quantity,threshold FROM stock WHERE quantity<=threshold").fetchall()
        low_names = {r[0] for r in low}
        db.execute("UPDATE low_stock_alerts SET active=0 WHERE active=1")
        for product, quantity, threshold in low:
            db.execute("""INSERT INTO low_stock_alerts(product,quantity,threshold,active,created_at,updated_at)
                VALUES(?,?,?,1,?,?) ON CONFLICT(product) DO UPDATE SET quantity=excluded.quantity,
                threshold=excluded.threshold,active=1,updated_at=excluded.updated_at""",
                (product, quantity, threshold, now, now))
        db.commit(); db.close()
    except sqlite3.Error:
        pass

def otp_digest(code, user_id):
    pepper = os.environ.get("OTP_SECRET", app.secret_key)
    return hashlib.sha256(f"{pepper}:{user_id}:{code}".encode()).hexdigest()

def mask_destination(value, channel):
    value = value or ""
    if channel == "email" and "@" in value:
        local, domain = value.split("@", 1)
        return (local[:1] + "***@" + domain)
    return ("*" * max(0, len(value)-4)) + value[-4:]

def deliver_otp(channel, destination, code):
    """Send through configured SMTP or Twilio; return (sent, demo_code_visible)."""
    if channel == "email" and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
        msg = (f"From: {os.environ['SMTP_FROM']}\r\nTo: {destination}\r\n"
               f"Subject: Vivasayi Connect TN password reset OTP\r\n\r\n"
               f"Your password reset code is {code}. It expires in 10 minutes. Do not share it.")
        host = os.environ["SMTP_HOST"]; port = int(os.environ.get("SMTP_PORT", "587"))
        with smtplib.SMTP(host, port, timeout=10) as server:
            server.starttls(context=ssl.create_default_context())
            if os.environ.get("SMTP_USER"):
                server.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            server.sendmail(os.environ["SMTP_FROM"], [destination], msg.encode())
        return True, False
    if channel == "sms" and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
        sid = os.environ["TWILIO_ACCOUNT_SID"]
        url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
        data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"],
             "Body": f"Vivasayi Connect TN password reset code: {code}. Expires in 10 minutes. Do not share."}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        import base64
        token = base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode()
        req.add_header("Authorization", "Basic " + token)
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=12) as response:
            if response.status not in (200, 201): raise RuntimeError("SMS provider rejected request")
        return True, False
    # Local demo only: do not expose OTP outside development.
    if os.environ.get("APP_ENV", "development").lower() != "production":
        app.logger.warning("DEMO password-reset OTP for %s: %s", destination, code)
        return False, True
    raise RuntimeError("OTP delivery is not configured")

def deliver_low_stock(channel, destination, product, quantity, threshold, unit):
    """Deliver an inventory alert using configured SMTP or Twilio; never expose demo secrets."""
    subject = f"Low stock alert: {product}"
    body = (f"Vivasayi Connect TN stock alert\n\n{product} is low: current quantity "
            f"{quantity:g} {unit}; threshold {threshold:g} {unit}. Please arrange replenishment.")
    if channel == "email" and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
        from email.message import EmailMessage
        msg = EmailMessage(); msg["From"] = os.environ["SMTP_FROM"]
        msg["To"] = destination; msg["Subject"] = subject; msg.set_content(body)
        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.environ.get("SMTP_PORT", "587")), timeout=12) as server:
            server.starttls(context=ssl.create_default_context())
            if os.environ.get("SMTP_USER"):
                server.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            server.send_message(msg)
        return
    if channel == "sms" and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
        sid = os.environ["TWILIO_ACCOUNT_SID"]
        url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
        data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"],
            "Body": f"Vivasayi Connect: LOW STOCK - {product}: {quantity:g} {unit} left; threshold {threshold:g}. Please replenish."}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        import base64
        token = base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode()
        req.add_header("Authorization", "Basic " + token)
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=12) as response:
            if response.status not in (200, 201): raise RuntimeError("SMS provider rejected request")
        return
    raise RuntimeError(f"{channel.upper()} provider is not configured")

def notify_low_stock(product, quantity, threshold, unit):
    """Notify active officers/admins once when stock crosses into low-stock state."""
    db = get_db()
    recipients = db.execute("SELECT username,phone,email FROM users WHERE is_active=1 AND role IN ('admin','officer')").fetchall()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    configured = []
    for user in recipients:
        if user["email"] and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
            configured.append((user["username"], "email", user["email"]))
        if user["phone"] and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
            configured.append((user["username"], "sms", user["phone"]))
    if not configured:
        app.logger.warning("LOW STOCK ALERT NOT SENT: no configured SMS/email provider or recipient for %s", product)
        db.execute("INSERT INTO low_stock_notifications(product,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?)",
                   (product, "", "none", "failed", "No configured provider/recipient", now)); db.commit()
        return
    for username, channel, destination in configured:
        status, error = "sent", None
        try:
            deliver_low_stock(channel, destination, product, quantity, threshold, unit)
        except Exception as exc:
            status, error = "failed", str(exc)[:300]
            app.logger.error("Low-stock %s delivery failed for %s: %s", channel, username, error)
        db.execute("INSERT INTO low_stock_notifications(product,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?)",
                   (product, username, channel, status, error, now))
    db.commit()

def log_audit(action, target="", details=""):
    db = get_db()
    db.execute("""INSERT INTO audit_logs(actor_id,actor_username,actor_role,action,target,details,ip_address,created_at)
                  VALUES(?,?,?,?,?,?,?,?)""",
               (session.get("user_id"), session.get("username"), session.get("role"), action[:100],
                str(target)[:200], str(details)[:500], (request.remote_addr or "")[:100],
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    db.commit()

def login_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                flash("Please log in to continue.", "error")
                return redirect(url_for("login", next=request.path))
            if roles and session.get("role") not in roles:
                abort(403)
            active = get_db().execute("SELECT is_active FROM users WHERE id=?", (session.get("user_id"),)).fetchone()
            if not active or not active["is_active"]:
                session.clear()
                flash("This account is disabled. Contact an administrator.", "error")
                return redirect(url_for("login"))
            return view(*args, **kwargs)
        return wrapped
    return decorator

@app.context_processor
def globals_for_templates():
    return {"lang":session.get("lang","en")}

@app.route("/language/<code>")
def language(code):
    if code in ("en","ta"): session["lang"]=code
    return redirect(request.referrer or url_for("index"))

@app.route("/")
@login_required("officer", "admin")
def index():
    return redirect(url_for("dashboard"))
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    stats={"products":len(stock),"low":sum(x["quantity"]<=x["threshold"] for x in stock),
      "pending":db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
      "requests":db.execute("SELECT COUNT(*) FROM requests").fetchone()[0]}
    recent=db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("index.html",stock=stock,stats=stats,recent=recent)

@app.route("/farmer",methods=["GET","POST"])
@login_required("farmer", "officer", "admin")
def farmer():
    db=get_db(); stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    if request.method=="POST":
        name=request.form.get("farmer_name","").strip(); village=request.form.get("village","").strip()
        society=request.form.get("society","").strip(); product=request.form.get("product","")
        phone=request.form.get("phone","").strip(); notes=request.form.get("notes","").strip()
        try: qty=float(request.form.get("quantity","0"))
        except ValueError: qty=0
        item=db.execute("SELECT unit FROM stock WHERE product=?",(product,)).fetchone()
        if not name or not village or not society or not item or qty<=0:
            flash("Please complete required fields and enter a quantity greater than zero.","error")
        else:
            db.execute("""INSERT INTO requests(farmer_name,phone,village,society,product,quantity,unit,notes,created_at)
             VALUES(?,?,?,?,?,?,?,?,?)""",(name,phone,village,society,product,qty,item["unit"],notes,datetime.now().strftime("%Y-%m-%d %H:%M")))
            db.commit(); flash("Request submitted successfully. Check your dashboard to see its status.","success")
            return redirect(url_for("dashboard"))
    return render_template("farmer.html",stock=stock)

@app.route("/requests")
@login_required("officer", "admin")
def requests_page():
    db=get_db(); q=request.args.get("q","").strip(); status=request.args.get("status","").strip()
    sql="SELECT * FROM requests WHERE 1=1"; args=[]
    if q:
        sql+=" AND (farmer_name LIKE ? OR village LIKE ? OR society LIKE ? OR CAST(id AS TEXT)=?)"
        args += [f"%{q}%"]*3+[q]
    if status in ("Pending","Approved","Fulfilled","Rejected"):
        sql+=" AND status=?"; args.append(status)
    rows=db.execute(sql+" ORDER BY id DESC",args).fetchall()
    return render_template("requests.html",rows=rows,q=q,status=status)

@app.route("/requests/<int:req_id>/status",methods=["POST"])
@login_required("officer", "admin")
def update_status(req_id):
    status=request.form.get("status","")
    if status not in ("Pending","Approved","Fulfilled","Rejected"): flash("Invalid status.","error")
    else:
        db=get_db()
        if db.execute("SELECT id FROM requests WHERE id=?",(req_id,)).fetchone():
            db.execute("UPDATE requests SET status=? WHERE id=?",(status,req_id)); db.commit()
            flash(f"Request #{req_id} updated to {status}.","success")
        else: flash("Request not found.","error")
    return redirect(request.referrer or url_for("requests_page"))

@app.route("/inventory",methods=["GET","POST"])
@login_required("officer", "admin")
def inventory():
    db=get_db()
    if request.method=="POST":
        action=request.form.get("action", "movement")
        if action == "add_product":
            product=request.form.get("product_name", "").strip()
            tamil_name=request.form.get("tamil_name", "").strip() or product
            category=request.form.get("category", "General").strip() or "General"
            tamil_category=request.form.get("tamil_category", "பொது").strip() or "பொது"
            unit=request.form.get("unit", "").strip()
            try:
                quantity=float(request.form.get("opening_quantity", "0"))
                threshold=float(request.form.get("threshold", "0"))
            except ValueError:
                quantity=-1; threshold=-1
            if not product or len(product)>100 or not unit or len(unit)>20 or quantity<0 or threshold<0:
                flash("Enter a product name, unit, and valid non-negative opening quantity and alert threshold.", "error")
            else:
                now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    db.execute("INSERT INTO stock(product,tamil_name,category,tamil_category,unit,quantity,threshold,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                               (product,tamil_name,category,tamil_category,unit,quantity,threshold,now))
                    if quantity > 0:
                        db.execute("INSERT INTO stock_moves(product,move_type,quantity,note,created_at) VALUES(?,?,?,?,?)",
                                   (product,"Stock In",quantity,"Opening balance",now))
                    db.commit(); log_audit("stock_product_created", product, f"opening_quantity={quantity}; threshold={threshold}")
                    flash(f"Product '{product}' added to the live inventory.", "success")
                    return redirect(url_for("inventory"))
                except sqlite3.IntegrityError:
                    db.rollback(); flash("A product with that name already exists.", "error")
            return redirect(url_for("inventory"))
        product=request.form.get("product", ""); move=request.form.get("move_type", "")
        note=request.form.get("note", "").strip()
        try: qty=float(request.form.get("quantity", "0"))
        except ValueError: qty=0
        row=db.execute("SELECT * FROM stock WHERE product=?",(product,)).fetchone()
        if not row or qty<=0 or move not in ("Stock In","Stock Out"):
            flash("Choose a product and enter a positive quantity.","error")
        elif move=="Stock Out" and row["quantity"]<qty:
            flash("Stock out quantity exceeds available stock.","error")
        else:
            newqty=row["quantity"]+qty if move=="Stock In" else row["quantity"]-qty
            was_low = row["quantity"] <= row["threshold"]
            now=datetime.now().strftime("%Y-%m-%d %H:%M")
            db.execute("UPDATE stock SET quantity=?,updated_at=? WHERE product=?",(newqty,now,product))
            db.execute("INSERT INTO stock_moves(product,move_type,quantity,note,created_at) VALUES(?,?,?,?,?)",(product,move,qty,note,now))
            db.commit()
            # Send only on the transition from healthy stock to low stock; no repeated SMS per page load.
            if not was_low and newqty <= row["threshold"]:
                notify_low_stock(product, newqty, row["threshold"], row["unit"])
                log_audit("low_stock_notification_triggered", product, f"quantity={newqty}; threshold={row['threshold']}")
            flash(f"{product} stock updated.","success")
        return redirect(url_for("inventory"))
    stock=db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    moves=db.execute("SELECT * FROM stock_moves ORDER BY id DESC LIMIT 15").fetchall()
    return render_template("inventory.html",stock=stock,moves=moves)

def send_announcement_sms(destination, title, message):
    """Send an operator-created announcement through configured Twilio SMS."""
    required = ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")
    if not all(os.environ.get(key) for key in required):
        raise RuntimeError("Twilio SMS is not configured")
    if not destination or not destination.startswith("+"):
        raise RuntimeError("Recipient phone must use international format, e.g. +919876543210")
    sid = os.environ["TWILIO_ACCOUNT_SID"]
    # Keep the notice concise; long notices may be sent as multi-part SMS by the provider.
    body = f"Vivasayi Connect TN: {title} — {message}"[:1500]
    data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"], "Body": body}).encode()
    req = urllib.request.Request(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json", data=data, method="POST")
    import base64
    token = base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode()
    req.add_header("Authorization", "Basic " + token)
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    with urllib.request.urlopen(req, timeout=15) as response:
        if response.status not in (200, 201):
            raise RuntimeError("SMS provider rejected request")

@app.route("/announcements",methods=["GET","POST"])
@login_required("officer", "admin")
def announcements():
    db=get_db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); message=request.form.get("message","").strip()
        audience=request.form.get("audience","All farmers").strip()
        valid_audiences = {"All farmers", "All officers/admins", "All registered users"}
        if not title or not message:
            flash("Enter a title and message.","error")
        elif audience not in valid_audiences:
            flash("Choose a valid audience.","error")
        else:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cur = db.execute("INSERT INTO announcements(title,message,audience,created_at) VALUES(?,?,?,?)",
                (title,message,audience,now)); announcement_id = cur.lastrowid; db.commit()
            if audience == "All farmers": roles = ("farmer",)
            elif audience == "All officers/admins": roles = ("officer", "admin")
            else: roles = ("farmer", "officer", "admin")
            marks = ",".join("?" for _ in roles)
            recipients = db.execute(f"SELECT id,phone FROM users WHERE is_active=1 AND role IN ({marks})", roles).fetchall()
            sent = failed = 0
            if not recipients:
                failed = 1
                db.execute("INSERT INTO announcement_deliveries(announcement_id,recipient_user_id,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?,?)",
                    (announcement_id, None, "", "sms", "failed", "No active users in selected audience", now))
            for user in recipients:
                phone = (user["phone"] or "").strip()
                status, error = "sent", None
                try:
                    if not phone:
                        raise RuntimeError("No mobile number registered")
                    send_announcement_sms(phone, title, message)
                    sent += 1
                except Exception as exc:
                    status, error = "failed", str(exc)[:300]
                    failed += 1
                    app.logger.warning("Announcement SMS failed for user_id=%s: %s", user["id"], error)
                db.execute("INSERT INTO announcement_deliveries(announcement_id,recipient_user_id,recipient,channel,status,error,created_at) VALUES(?,?,?,?,?,?,?)",
                    (announcement_id, user["id"], phone[-4:].rjust(len(phone), "*") if phone else "", "sms", status, error, now))
            db.commit()
            log_audit("announcement_sms_sent", str(announcement_id), f"audience={audience}; sent={sent}; failed={failed}")
            if sent and not failed:
                flash(f"Announcement saved. SMS provider accepted {sent} message(s). Delivery can take a short time.", "success")
            elif sent:
                flash(f"Announcement saved. SMS accepted for {sent} recipient(s); {failed} failed. Check Twilio settings and delivery log.", "warning")
            else:
                if recipients:
                    flash(f"Announcement saved, but no SMS was sent successfully ({failed} failed). Configure Twilio and check recipient numbers.", "error")
                else:
                    flash("Announcement saved, but no active users were found for that audience.", "error")
            return redirect(url_for("announcements"))
    rows=db.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    return render_template("announcements.html",rows=rows)

@app.route("/ivr")
@login_required("farmer", "officer", "admin")
def ivr():
    stock = get_db().execute("SELECT product,tamil_name,quantity,unit FROM stock ORDER BY product").fetchall()
    return render_template("ivr.html", stock=stock)

@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        name = request.form.get("display_name", "").strip()
        phone = re.sub(r"[\s()-]", "", request.form.get("phone", "").strip())
        email = request.form.get("email", "").strip().lower()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if not all((name, phone, email, username, password, confirm)):
            flash("Please complete every field.", "error")
        elif not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username):
            flash("Username must be 3–30 characters (letters, numbers, ., _ or -).", "error")
        elif not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            flash("Enter a valid email address.", "error")
        elif len(re.sub(r"\D", "", phone)) < 10:
            flash("Enter a valid mobile number including country code if needed.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            db = get_db()
            exists = db.execute("SELECT 1 FROM users WHERE username=? OR lower(email)=? OR phone=?", (username, email, phone)).fetchone()
            if exists:
                flash("Username, email or mobile number is already registered.", "error")
            else:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                db.execute("INSERT INTO users(username,password_hash,role,display_name,phone,email,is_active,created_at) VALUES(?,?,?,?,?,?,1,?)",
                           (username, generate_password_hash(password), "farmer", name, phone, email, now))
                db.commit()
                flash("Account created successfully. Please log in.", "success")
                return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and user["is_active"] and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["id"], username=user["username"], role=user["role"],
                           display_name=user["display_name"], phone=user["phone"], lang="en")
            log_audit("login_success", user["username"], "Successful login")
            flash("Welcome, " + user["display_name"] + "!", "success")
            return redirect(url_for("dashboard"))
        log_audit("login_failed", username, "Invalid credentials or inactive account")
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/login/otp", methods=["GET", "POST"])
def login_otp_request():
    """Request a one-time sign-in code using a registered email or mobile number."""
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        channel = request.form.get("channel", "email")
        if channel not in ("email", "sms") or not identifier:
            flash("Enter your registered email/mobile and choose a delivery method.", "error")
            return render_template("login_otp_request.html")
        field = "email" if channel == "email" else "phone"
        normalized = identifier.lower() if channel == "email" else re.sub(r"[\s()-]", "", identifier)
        user = get_db().execute(f"SELECT * FROM users WHERE lower({field})=? AND is_active=1", (normalized,)).fetchone()
        # Generic response avoids revealing whether an account is registered.
        generic = "If an active account matches those details, a sign-in code will be sent."
        if user and user[field]:
            db = get_db(); now = datetime.now(); now_s = now.strftime("%Y-%m-%d %H:%M:%S")
            recent = db.execute("SELECT COUNT(*) FROM password_otps WHERE user_id=? AND created_at>=?", (user["id"], (now-timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S"))).fetchone()[0]
            if recent < 3:
                code = f"{secrets.randbelow(1000000):06d}"
                db.execute("UPDATE password_otps SET used=1 WHERE user_id=? AND used=0", (user["id"],))
                db.execute("INSERT INTO password_otps(user_id,channel,destination,otp_hash,expires_at,created_at) VALUES(?,?,?,?,?,?)",
                    (user["id"], channel, mask_destination(user[field], channel), otp_digest(code,user["id"]), (now+timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S"), now_s))
                db.commit()
                try:
                    destination = user[field]
                    if channel == "email" and os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM"):
                        from email.message import EmailMessage
                        msg = EmailMessage(); msg["From"] = os.environ["SMTP_FROM"]; msg["To"] = destination
                        msg["Subject"] = "Vivasayi Connect TN sign-in code"
                        msg.set_content(f"Your sign-in code is {code}. It expires in 10 minutes. Do not share this code.")
                        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.environ.get("SMTP_PORT", "587")), timeout=12) as server:
                            server.starttls(context=ssl.create_default_context())
                            if os.environ.get("SMTP_USER"):
                                server.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
                            server.send_message(msg)
                        demo = False
                    elif channel == "sms" and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM")):
                        sid = os.environ["TWILIO_ACCOUNT_SID"]
                        data = urllib.parse.urlencode({"To": destination, "From": os.environ["TWILIO_FROM"], "Body": f"Vivasayi Connect TN sign-in code: {code}. Expires in 10 minutes. Do not share."}).encode()
                        req = urllib.request.Request(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json", data=data, method="POST")
                        import base64
                        req.add_header("Authorization", "Basic " + base64.b64encode(f"{sid}:{os.environ['TWILIO_AUTH_TOKEN']}".encode()).decode())
                        req.add_header("Content-Type", "application/x-www-form-urlencoded")
                        with urllib.request.urlopen(req, timeout=12) as response:
                            if response.status not in (200, 201): raise RuntimeError("SMS provider rejected request")
                        demo = False
                    elif os.environ.get("APP_ENV", "development").lower() != "production":
                        app.logger.warning("DEMO sign-in OTP for %s: %s", mask_destination(destination, channel), code)
                        demo = True
                    else:
                        raise RuntimeError("OTP delivery is not configured")
                    session["login_otp_user_id"] = user["id"]
                    session["login_otp_channel"] = channel
                    session["login_otp_demo_code"] = code if demo else None
                    log_audit("login_otp_requested", user["username"], f"Channel={channel}; destination={mask_destination(destination,channel)}")
                    flash("Demo sign-in code: " + code if demo else generic, "success")
                    return redirect(url_for("login_otp_verify"))
                except Exception as exc:
                    app.logger.error("Sign-in OTP delivery failed: %s", exc)
                    log_audit("login_otp_delivery_failed", user["username"], f"Channel={channel}")
        flash(generic, "success")
    return render_template("login_otp_request.html")

@app.route("/login/otp/verify", methods=["GET", "POST"])
def login_otp_verify():
    user_id = session.get("login_otp_user_id")
    if not user_id: return redirect(url_for("login_otp_request"))
    if request.method == "POST":
        code = request.form.get("otp", "").strip()
        db = get_db(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = db.execute("SELECT * FROM password_otps WHERE user_id=? AND used=0 ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
        if not row or row["expires_at"] < now or row["attempts"] >= 5:
            flash("Code expired or attempt limit reached. Request a new code.", "error")
        elif secrets.compare_digest(row["otp_hash"], otp_digest(code, user_id)):
            user = db.execute("SELECT * FROM users WHERE id=? AND is_active=1", (user_id,)).fetchone()
            if not user:
                flash("Account is inactive. Contact an administrator.", "error")
            else:
                db.execute("UPDATE password_otps SET used=1 WHERE id=?", (row["id"],)); db.commit()
                session.clear(); session.update(user_id=user["id"], username=user["username"], role=user["role"], display_name=user["display_name"], phone=user["phone"], lang="en")
                log_audit("login_otp_success", user["username"], "OTP login successful")
                flash("Welcome, " + user["display_name"] + "!", "success")
                return redirect(url_for("dashboard"))
        else:
            db.execute("UPDATE password_otps SET attempts=attempts+1 WHERE id=?", (row["id"],)); db.commit()
            log_audit("login_otp_failed", str(user_id), "Incorrect sign-in OTP")
            flash("Incorrect code. Try again.", "error")
    return render_template("login_otp_verify.html", channel=session.get("login_otp_channel", "email"), demo_code=session.get("login_otp_demo_code"))

@app.route("/password/forgot", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        for key in ("otp_user_id", "otp_username", "otp_channel", "otp_verified_user_id", "otp_demo_code"):
            session.pop(key, None)
        username = request.form.get("username", "").strip().lower()
        channel = request.form.get("channel", "email")
        contact = request.form.get("contact", "").strip()
        generic = "If the account and registered contact match, a reset code will be sent."
        if channel not in ("email", "sms"):
            flash(generic, "success"); return render_template("forgot_password.html")
        db = get_db()
        field = "email" if channel == "email" else "phone"
        user = db.execute(f"SELECT id,username,{field} AS contact FROM users WHERE username=? AND is_active=1", (username,)).fetchone()
        # Require exact registered contact match; don't reveal whether an account exists.
        if user and user["contact"] and contact and user["contact"].strip().lower() == contact.strip().lower():
            now = datetime.now(); now_s = now.strftime("%Y-%m-%d %H:%M:%S")
            recent = db.execute("SELECT COUNT(*) FROM password_otps WHERE user_id=? AND created_at>=?",
                (user["id"], (now-timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S"))).fetchone()[0]
            if recent < 3:
                code = f"{secrets.randbelow(1000000):06d}"
                db.execute("UPDATE password_otps SET used=1 WHERE user_id=? AND used=0", (user["id"],))
                db.execute("INSERT INTO password_otps(user_id,channel,destination,otp_hash,expires_at,created_at) VALUES(?,?,?,?,?,?)",
                    (user["id"], channel, mask_destination(user["contact"], channel), otp_digest(code,user["id"]),
                     (now+timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S"), now_s))
                db.commit()
                try:
                    sent, demo = deliver_otp(channel, user["contact"], code)
                    session["otp_user_id"] = user["id"]
                    session["otp_username"] = user["username"]
                    session["otp_channel"] = channel
                    session["otp_demo_code"] = code if demo else None
                    log_audit("password_otp_requested", username, f"Channel={channel}; destination={mask_destination(user['contact'],channel)}")
                    flash("Demo OTP: " + code if demo else generic, "success")
                    return redirect(url_for("verify_otp"))
                except Exception as exc:
                    app.logger.error("OTP delivery failed: %s", exc)
                    log_audit("password_otp_delivery_failed", username, f"Channel={channel}")
            else:
                log_audit("password_otp_rate_limited", username, "OTP request limit reached")
        flash(generic, "success")
    return render_template("forgot_password.html")

@app.route("/password/verify", methods=["GET", "POST"])
def verify_otp():
    user_id = session.get("otp_user_id")
    if not user_id: return redirect(url_for("forgot_password"))
    if request.method == "POST":
        code = request.form.get("otp", "").strip()
        db = get_db(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = db.execute("SELECT * FROM password_otps WHERE user_id=? AND used=0 ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
        if not row or row["expires_at"] < now or row["attempts"] >= 5:
            flash("Code expired or attempt limit reached. Request a new code.", "error")
        elif secrets.compare_digest(row["otp_hash"], otp_digest(code, user_id)):
            db.execute("UPDATE password_otps SET used=1 WHERE id=?", (row["id"],)); db.commit()
            session["otp_verified_user_id"] = user_id
            session.pop("otp_demo_code", None)
            log_audit("password_otp_verified", session.get("otp_username", ""), "OTP verified")
            return redirect(url_for("reset_password"))
        else:
            db.execute("UPDATE password_otps SET attempts=attempts+1 WHERE id=?", (row["id"],)); db.commit()
            log_audit("password_otp_failed", session.get("otp_username", ""), "Incorrect OTP")
            flash("Incorrect code. Try again.", "error")
    return render_template("verify_otp.html", channel=session.get("otp_channel", "email"))

@app.route("/password/reset", methods=["GET", "POST"])
def reset_password():
    user_id = session.get("otp_verified_user_id")
    if not user_id: return redirect(url_for("forgot_password"))
    if request.method == "POST":
        new = request.form.get("new_password", ""); confirm = request.form.get("confirm_password", "")
        if len(new) < 10: flash("Password must be at least 10 characters.", "error")
        elif new != confirm: flash("Passwords do not match.", "error")
        else:
            db = get_db(); user = db.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), user_id)); db.commit()
            log_audit("password_reset_otp", user["username"] if user else "", "Password reset with verified OTP")
            for key in ("otp_user_id", "otp_username", "otp_channel", "otp_verified_user_id", "otp_demo_code"):
                session.pop(key, None)
            flash("Password reset complete. Please log in with your new password.", "success")
            return redirect(url_for("login"))
    return render_template("reset_password.html")

@app.route("/logout", methods=["POST"])
def logout():
    if session.get("user_id"):
        log_audit("logout", session.get("username", ""), "User logged out")
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/societies", methods=["GET"])
@login_required()
def society_finder():
    """Search the locally imported society directory; no unverified live data is implied."""
    db = get_db()
    q = request.args.get("q", "").strip()[:100]
    district = request.args.get("district", "").strip()[:80]
    pincode = request.args.get("pincode", "").strip()[:6]
    mode = request.args.get("mode", "village")
    try:
        lat = float(request.args.get("lat", ""))
        lon = float(request.args.get("lon", ""))
        if not (-90 <= lat <= 90 and -180 <= lon <= 180): raise ValueError()
        gps_valid = True
    except (TypeError, ValueError):
        lat = lon = None; gps_valid = False
    try: radius = max(1, min(100, int(request.args.get("radius", "25"))))
    except ValueError: radius = 25
    clauses, args = [], []
    if q:
        clauses.append("(name LIKE ? OR village LIKE ? OR block LIKE ? OR district LIKE ? OR address LIKE ? OR society_code LIKE ?)")
        args.extend([f"%{q}%"] * 6)
    if district:
        clauses.append("district LIKE ?"); args.append(f"%{district}%")
    if pincode:
        clauses.append("pincode LIKE ?"); args.append(f"{pincode}%")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    rows = db.execute("SELECT * FROM cooperative_societies" + where + " ORDER BY district, village, name LIMIT 10000", args).fetchall()
    results = []
    for row in rows:
        item = dict(row); item["distance_km"] = None
        if gps_valid and item.get("latitude") is not None and item.get("longitude") is not None:
            p1, p2 = math.radians(lat), math.radians(float(item["latitude"]))
            dp = math.radians(float(item["latitude"]) - lat); dl = math.radians(float(item["longitude"]) - lon)
            a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
            item["distance_km"] = 6371 * 2 * math.asin(min(1, math.sqrt(a)))
            if mode == "gps" and item["distance_km"] > radius: continue
        elif mode == "gps":
            # Unknown coordinates are not falsely ranked as nearby.
            continue
        results.append(item)
    if mode == "gps": results.sort(key=lambda x: x["distance_km"] if x["distance_km"] is not None else float("inf"))
    districts = db.execute("SELECT DISTINCT district FROM cooperative_societies WHERE district<>'' ORDER BY district").fetchall()
    total = db.execute("SELECT COUNT(*) FROM cooperative_societies").fetchone()[0]
    verified = db.execute("SELECT COUNT(*) FROM cooperative_societies WHERE data_status='Verified'").fetchone()[0]
    return render_template("societies.html", rows=results, q=q, district=district, pincode=pincode,
        mode=mode, lat=lat if gps_valid else None, lon=lon if gps_valid else None, radius=radius,
        districts=[r[0] for r in districts], total=total, verified=verified)

@app.route("/admin/societies/import", methods=["GET", "POST"])
@login_required("admin")
def society_import():
    db = get_db()
    if request.method == "POST":
        upload = request.files.get("file")
        if not upload or not upload.filename or not upload.filename.lower().endswith(".csv"):
            flash("Please choose a CSV file.", "error")
            return redirect(url_for("society_import"))
        if request.content_length and request.content_length > 5 * 1024 * 1024:
            flash("CSV file must be 5 MB or smaller.", "error")
            return redirect(url_for("society_import"))
        try:
            content = upload.stream.read(5 * 1024 * 1024 + 1)
            if len(content) > 5 * 1024 * 1024: raise ValueError("File exceeds 5 MB limit.")
            text_data = content.decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(text_data))
            if not reader.fieldnames: raise ValueError("CSV needs a header row.")
            headers = {h.strip().lower(): h for h in reader.fieldnames if h}
            required = {"name"}
            if not any(a in headers for a in ["name", "society_name", "paccs_name"]): raise ValueError("CSV must contain a name, society_name, or paccs_name column.")
            aliases = {
                "society_code": ["society_code", "code", "mfms_id", "registration_no"],
                "name": ["name", "society_name", "paccs_name"], "district": ["district"],
                "block": ["block", "taluk", "taluka"], "village": ["village", "town"],
                "pincode": ["pincode", "pin_code", "postal_code"], "address": ["address"],
                "phone": ["phone", "mobile", "contact_number", "telephone"], "email": ["email"],
                "latitude": ["latitude", "lat"], "longitude": ["longitude", "lon", "lng"],
                "services": ["services"], "source_name": ["source_name", "source"],
                "source_url": ["source_url", "source_link"], "verified_at": ["verified_at"],
                "data_status": ["data_status", "verification_status"]}
            mapping = {field: next((headers[a] for a in names if a in headers), None) for field,names in aliases.items()}
            seen=added=updated=skipped=0
            now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for raw in reader:
                seen += 1
                val=lambda field: (raw.get(mapping.get(field), "") or "").strip()[:500] if mapping.get(field) else ""
                name=val("name")
                if not name: skipped += 1; continue
                code=val("society_code"); district_val=val("district"); village_val=val("village")
                def coord(field, low, high):
                    rawv=val(field)
                    if not rawv: return None
                    try:
                        n=float(rawv)
                        if low <= n <= high: return n
                    except ValueError: pass
                    return None
                latv=coord("latitude", -90, 90); lonv=coord("longitude", -180, 180)
                status=val("data_status")
                if status.lower() not in ("verified", "unverified", "needs review"):
                    status="Unverified"
                verified_at=val("verified_at") if status == "Verified" else ""
                source_url=val("source_url")
                if source_url and not source_url.lower().startswith(("https://", "http://")):
                    source_url=""
                # Do not accept a Verified label without a source and verification date.
                if status == "Verified" and not (verified_at and (val("source_name") or source_url)):
                    status="Needs review"; verified_at=""
                existing=None
                if code:
                    existing=db.execute("SELECT id FROM cooperative_societies WHERE society_code=? AND district=? LIMIT 1",(code,district_val)).fetchone()
                if not existing:
                    existing=db.execute("SELECT id FROM cooperative_societies WHERE lower(name)=lower(?) AND lower(district)=lower(?) AND lower(village)=lower(?) LIMIT 1",(name,district_val,village_val)).fetchone()
                fields=[code,name,district_val,val("block"),village_val,val("pincode"),val("address"),val("phone"),val("email"),latv,lonv,val("services"),val("source_name"),source_url,verified_at,status]
                if existing:
                    db.execute("""UPDATE cooperative_societies SET society_code=?,name=?,district=?,block=?,village=?,pincode=?,address=?,phone=?,email=?,latitude=?,longitude=?,services=?,source_name=?,source_url=?,verified_at=?,data_status=?,updated_at=? WHERE id=?""",fields+[now,existing[0]])
                    updated += 1
                else:
                    db.execute("""INSERT INTO cooperative_societies(society_code,name,district,block,village,pincode,address,phone,email,latitude,longitude,services,source_name,source_url,verified_at,data_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",fields+[now,now])
                    added += 1
            db.execute("INSERT INTO society_directory_imports(filename,imported_by,rows_seen,rows_added,rows_updated,rows_skipped,created_at) VALUES(?,?,?,?,?,?,?)",
                (upload.filename[:200],session.get("username","admin"),seen,added,updated,skipped,now))
            db.commit()
            log_audit("society_directory_import", upload.filename[:200], f"seen={seen}, added={added}, updated={updated}, skipped={skipped}")
            flash(f"Import complete: {added} added, {updated} updated, {skipped} skipped. Imported rows remain unverified unless explicitly marked Verified with a verification date.", "success")
        except (UnicodeDecodeError, csv.Error, ValueError, sqlite3.Error) as exc:
            db.rollback(); flash(f"CSV import failed: {str(exc)[:220]}", "error")
        return redirect(url_for("society_import"))
    history=db.execute("SELECT * FROM society_directory_imports ORDER BY id DESC LIMIT 20").fetchall()
    return render_template("society_import.html", history=history)

@app.route("/dashboard")
@login_required()
def dashboard():
    role = session.get("role")
    db = get_db()
    if role == "officer":
        stats = {"pending": db.execute("SELECT COUNT(*) FROM requests WHERE status='Pending'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0],
                 "products": db.execute("SELECT COUNT(*) FROM stock").fetchone()[0]}
        recent = db.execute("SELECT * FROM requests ORDER BY id DESC LIMIT 6").fetchall()
        chart_status = db.execute("SELECT status,COUNT(*) total FROM requests GROUP BY status ORDER BY status").fetchall()
        chart_stock = db.execute("SELECT product,quantity,threshold FROM stock ORDER BY product").fetchall()
        alerts = db.execute("SELECT * FROM low_stock_alerts WHERE active=1 ORDER BY quantity,product").fetchall()
        return render_template("officer_dashboard.html", stats=stats, recent=recent, chart_status=chart_status, chart_stock=chart_stock, alerts=alerts)
    if role == "admin":
        stats = {"users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                 "farmers": db.execute("SELECT COUNT(*) FROM users WHERE role='farmer'").fetchone()[0],
                 "officers": db.execute("SELECT COUNT(*) FROM users WHERE role='officer'").fetchone()[0],
                 "requests": db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
                 "low": db.execute("SELECT COUNT(*) FROM stock WHERE quantity<=threshold").fetchone()[0]}
        users = db.execute("SELECT username,display_name,role FROM users ORDER BY role,username").fetchall()
        chart_status = db.execute("SELECT status,COUNT(*) total FROM requests GROUP BY status ORDER BY status").fetchall()
        chart_stock = db.execute("SELECT product,quantity,threshold FROM stock ORDER BY product").fetchall()
        alerts = db.execute("SELECT * FROM low_stock_alerts WHERE active=1 ORDER BY quantity,product").fetchall()
        return render_template("admin_dashboard.html", stats=stats, users=users, chart_status=chart_status, chart_stock=chart_stock, alerts=alerts)
    # Farmers see requests associated with their registered mobile number.
    rows = db.execute("SELECT * FROM requests WHERE phone=? ORDER BY id DESC", (session.get("phone", ""),)).fetchall()
    stock = db.execute("SELECT * FROM stock ORDER BY product").fetchall()
    return render_template("farmer_dashboard.html", rows=rows, stock=stock)

@app.route("/admin/users", methods=["GET", "POST"])
@login_required("admin")
def admin_users():
    db = get_db()
    if request.method == "POST":
        action = request.form.get("action", "create")
        if action == "create":
            username = request.form.get("username", "").strip().lower()
            display_name = request.form.get("display_name", "").strip()
            phone = request.form.get("phone", "").strip()
            email = request.form.get("email", "").strip().lower()
            role = request.form.get("role", "")
            password = request.form.get("password", "")
            if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
                flash("Username must be 3–32 characters: letters, numbers, dot, underscore or hyphen.", "error")
            elif not display_name or role not in ("farmer", "officer", "admin"):
                flash("Enter a display name and valid role.", "error")
            elif len(password) < 10:
                flash("Initial password must be at least 10 characters.", "error")
            else:
                try:
                    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cur = db.execute("INSERT INTO users(username,password_hash,role,display_name,phone,email,created_at) VALUES(?,?,?,?,?,?,?)",
                                     (username, generate_password_hash(password), role, display_name, phone, email, now))
                    db.commit(); log_audit("user_created", username, f"Created {role} account (id={cur.lastrowid})")
                    flash(f"Account '{username}' created. Share the initial password securely.", "success")
                    return redirect(url_for("admin_users"))
                except sqlite3.IntegrityError:
                    db.rollback(); flash("That username already exists.", "error")
        elif action == "toggle":
            try: target_id = int(request.form.get("user_id", "0"))
            except ValueError: target_id = 0
            target = db.execute("SELECT id,username,role,is_active FROM users WHERE id=?", (target_id,)).fetchone()
            if not target: flash("Account not found.", "error")
            elif target["id"] == session.get("user_id"): flash("You cannot disable your own account.", "error")
            elif target["role"] == "admin" and target["is_active"] and db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1").fetchone()[0] <= 1:
                flash("Cannot disable the last active admin account.", "error")
            else:
                active = 0 if target["is_active"] else 1
                db.execute("UPDATE users SET is_active=? WHERE id=?", (active, target_id)); db.commit()
                log_audit("user_disabled" if not active else "user_enabled", target["username"], "Account status changed by admin")
                flash(f"Account '{target['username']}' {'disabled' if not active else 'enabled'}.", "success")
                return redirect(url_for("admin_users"))
        elif action == "reset_password":
            try: target_id = int(request.form.get("user_id", "0"))
            except ValueError: target_id = 0
            password = request.form.get("new_password", "")
            target = db.execute("SELECT id,username FROM users WHERE id=?", (target_id,)).fetchone()
            if not target: flash("Account not found.", "error")
            elif len(password) < 10: flash("New password must be at least 10 characters.", "error")
            else:
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), target_id)); db.commit()
                log_audit("admin_password_reset", target["username"], "Password reset by administrator")
                flash(f"Password reset for '{target['username']}'. Tell the user securely.", "success")
                return redirect(url_for("admin_users"))
    users = db.execute("SELECT id,username,display_name,role,phone,email,is_active,created_at FROM users ORDER BY role,username").fetchall()
    return render_template("admin_users.html", users=users)

@app.route("/account/password", methods=["GET", "POST"])
@login_required()
def change_password():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        user = get_db().execute("SELECT password_hash FROM users WHERE id=?", (session["user_id"],)).fetchone()
        if not user or not check_password_hash(user["password_hash"], current): flash("Current password is incorrect.", "error")
        elif len(new) < 10: flash("New password must be at least 10 characters.", "error")
        elif new != confirm: flash("New passwords do not match.", "error")
        elif check_password_hash(user["password_hash"], new): flash("Choose a password different from your current password.", "error")
        else:
            db = get_db(); db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), session["user_id"]))
            db.commit(); log_audit("password_changed", session.get("username", ""), "User changed own password")
            flash("Password changed successfully.", "success"); return redirect(url_for("dashboard"))
    return render_template("change_password.html")

@app.route("/admin/audit")
@login_required("admin")
def audit_logs():
    db = get_db(); action = request.args.get("action", "").strip()[:100]
    username = request.args.get("username", "").strip()[:100]
    start = request.args.get("start", "").strip(); end = request.args.get("end", "").strip()
    sql = "SELECT * FROM audit_logs WHERE 1=1"; args = []
    if action: sql += " AND action LIKE ?"; args.append("%" + action + "%")
    if username: sql += " AND (actor_username LIKE ? OR target LIKE ?)"; args += ["%"+username+"%", "%"+username+"%"]
    if start and re.fullmatch(r"\d{4}-\d{2}-\d{2}", start): sql += " AND date(created_at)>=date(?)"; args.append(start)
    if end and re.fullmatch(r"\d{4}-\d{2}-\d{2}", end): sql += " AND date(created_at)<=date(?)"; args.append(end)
    rows = db.execute(sql + " ORDER BY id DESC LIMIT 500", args).fetchall()
    return render_template("audit_logs.html", rows=rows, action=action, username=username, start=start, end=end)

@app.route("/admin/reports")
@login_required("admin")
def user_activity_reports():
    db = get_db()
    days_raw = request.args.get("days", "30")
    days = int(days_raw) if days_raw in ("7", "30", "90") else 30
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    summary = db.execute("""SELECT action, COUNT(*) AS total FROM audit_logs
        WHERE created_at >= ? GROUP BY action ORDER BY total DESC, action""", (since,)).fetchall()
    people = db.execute("""SELECT actor_username, actor_role,
        SUM(CASE WHEN action='login_success' THEN 1 ELSE 0 END) AS successful_logins,
        SUM(CASE WHEN action='login_failed' THEN 1 ELSE 0 END) AS failed_logins,
        COUNT(*) AS events, MAX(created_at) AS last_activity
        FROM audit_logs WHERE created_at >= ? AND actor_username IS NOT NULL
        GROUP BY actor_username, actor_role ORDER BY events DESC, actor_username""", (since,)).fetchall()
    return render_template("activity_reports.html", days=days, summary=summary, people=people)

@app.route("/admin/audit/export.csv")
@login_required("admin")
def export_audit_csv():
    db=get_db(); action=request.args.get("action","").strip()[:100]; username=request.args.get("username","").strip()[:100]
    start=request.args.get("start","").strip(); end=request.args.get("end","").strip()
    sql="SELECT id,actor_username,actor_role,action,target,details,ip_address,created_at FROM audit_logs WHERE 1=1"; args=[]
    if action: sql+=" AND action LIKE ?"; args.append("%"+action+"%")
    if username: sql+=" AND (actor_username LIKE ? OR target LIKE ?)"; args += ["%"+username+"%","%"+username+"%"]
    if start and re.fullmatch(r"\d{4}-\d{2}-\d{2}",start): sql+=" AND date(created_at)>=date(?)"; args.append(start)
    if end and re.fullmatch(r"\d{4}-\d{2}-\d{2}",end): sql+=" AND date(created_at)<=date(?)"; args.append(end)
    rows=db.execute(sql+" ORDER BY id DESC LIMIT 10000",args).fetchall()
    out=io.StringIO(); w=csv.writer(out); w.writerow(rows[0].keys() if rows else ["id","actor_username","actor_role","action","target","details","ip_address","created_at"])
    for row in rows: w.writerow([row[k] for k in row.keys()])
    from flask import Response
    log_audit("audit_export_csv", "audit_logs", f"Exported {len(rows)} rows")
    return Response('\ufeff'+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":"attachment; filename=vivasayi_audit_log.csv"})

@app.route("/admin/reports/export/<kind>")
@login_required("officer", "admin")
def export_report(kind):
    if kind not in ("csv","xlsx"): abort(404)
    db=get_db()
    report=request.args.get("report","requests")
    if report=="inventory":
        if session.get("role") != "admin": abort(403)
        headers=["product","tamil_name","category","unit","quantity","threshold","updated_at"]
        rows=db.execute("SELECT product,tamil_name,category,unit,quantity,threshold,updated_at FROM stock ORDER BY product").fetchall()
    else:
        report="requests"; headers=["id","farmer_name","phone","village","society","product","quantity","unit","notes","status","created_at"]
        rows=db.execute("SELECT id,farmer_name,phone,village,society,product,quantity,unit,notes,status,created_at FROM requests ORDER BY id DESC").fetchall()
    if kind=="csv":
        out=io.StringIO(); w=csv.writer(out); w.writerow(headers)
        for row in rows: w.writerow([row[h] for h in headers])
        from flask import Response
        response=Response('\ufeff'+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":f"attachment; filename=vivasayi_{report}.csv"})
    else:
        try: from openpyxl import Workbook
        except ImportError: abort(503, description="Excel export requires openpyxl. Install requirements.txt and retry.")
        wb=Workbook(); ws=wb.active; ws.title=report.title(); ws.append(headers)
        for row in rows: ws.append([row[h] for h in headers])
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        for col in ws.columns:
            letter=col[0].column_letter; ws.column_dimensions[letter].width=min(max(max(len(str(c.value or "")) for c in col)+2,12),36)
        data=io.BytesIO(); wb.save(data); data.seek(0)
        from flask import Response
        response=Response(data.getvalue(),mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":f"attachment; filename=vivasayi_{report}.xlsx"})
    log_audit("report_export", report, f"Format={kind}; rows={len(rows)}")
    return response

def _haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2-lat1), math.radians(lon2-lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 6371 * 2 * math.asin(min(1, math.sqrt(a)))

@app.route("/resilience", methods=["GET", "POST"])
@login_required("officer", "admin")
def resilience_workspace():
    db = get_db()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if request.method == "POST":
        action = request.form.get("action", "")
        if action == "demand":
            requester = request.form.get("requester", "").strip()[:100]
            village = request.form.get("village", "").strip()[:100]
            district = request.form.get("district", "").strip()[:80]
            input_type = request.form.get("input_type", "").strip()[:80]
            unit = request.form.get("unit", "bags").strip()[:20]
            try: qty = float(request.form.get("quantity", "0"))
            except ValueError: qty = 0
            try:
                lat = float(request.form.get("latitude", "")); lon = float(request.form.get("longitude", ""))
                if not (-90 <= lat <= 90 and -180 <= lon <= 180): raise ValueError()
            except (ValueError, TypeError): lat = lon = None
            if not all((requester, village, district, input_type, unit)) or qty <= 0:
                flash("Enter requester, location, input type and a positive quantity.", "error")
            else:
                db.execute("INSERT INTO input_demands(requester,village,district,input_type,quantity,unit,latitude,longitude,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (requester,village,district,input_type,qty,unit,lat,lon,now))
                db.commit(); log_audit("resilience_demand_created", input_type, f"quantity={qty} {unit}; district={district}")
                flash("Demand saved. Potential matches are proposals only; no transfer has been initiated.", "success")
            return redirect(url_for("resilience_workspace"))
        if action == "match":
            try: demand_id = int(request.form.get("demand_id", "0"))
            except ValueError: demand_id = 0
            demand = db.execute("SELECT * FROM input_demands WHERE id=?", (demand_id,)).fetchone()
            if not demand:
                flash("Demand not found.", "error")
            else:
                stocks = db.execute("SELECT s.*,p.name,p.district,p.village,p.latitude,p.longitude,p.fictional FROM demo_stock s JOIN demo_paccs p ON p.id=s.paccs_id WHERE lower(s.input_type)=lower(?) AND lower(s.unit)=lower(?) AND s.verified=1 AND s.quantity>=? AND date(s.valid_until)>=date('now')", (demand["input_type"], demand["unit"], demand["quantity"])).fetchall()
                created = 0
                for stock in stocks:
                    if demand["district"].lower() != stock["district"].lower():
                        continue
                    distance = None
                    if demand["latitude"] is not None and demand["longitude"] is not None:
                        distance = _haversine_km(demand["latitude"], demand["longitude"], stock["latitude"], stock["longitude"])
                    reasons = [f"Input type matches: {stock['input_type']}", f"Verified sample quantity {stock['quantity']:g} {stock['unit']} covers demand {demand['quantity']:g} {demand['unit']}", f"Stock validity date {stock['valid_until']} is current"]
                    if distance is not None: reasons.append(f"Approximate straight-line distance {distance:.1f} km")
                    reasons.append("Fictional demonstration PACCS record; confirm real stock before any action")
                    exists = db.execute("SELECT id FROM redistribution_reviews WHERE demand_id=? AND stock_id=? AND status='Pending'", (demand_id, stock["id"])).fetchone()
                    if not exists:
                        db.execute("INSERT INTO redistribution_reviews(demand_id,stock_id,match_reasons,created_at) VALUES(?,?,?,?)", (demand_id, stock["id"], "\n".join(reasons), now)); created += 1
                db.commit(); log_audit("resilience_match_proposed", str(demand_id), f"new_proposals={created}; no transfer initiated")
                flash(f"Created {created} pending proposal(s). No stock has been moved.", "success" if created else "error")
            return redirect(url_for("resilience_workspace"))
        if action == "decision":
            try: review_id = int(request.form.get("review_id", "0"))
            except ValueError: review_id = 0
            decision = request.form.get("decision", "")
            note = request.form.get("note", "").strip()[:300]
            review = db.execute("SELECT * FROM redistribution_reviews WHERE id=?", (review_id,)).fetchone()
            if not review or review["status"] != "Pending" or decision not in ("Approved for further coordination", "Rejected"):
                flash("Invalid decision or proposal is no longer pending.", "error")
            else:
                new_status = "Approved for further coordination" if decision.startswith("Approved") else "Rejected"
                db.execute("UPDATE redistribution_reviews SET status=?,officer_decision=?,decision_by=?,decision_at=? WHERE id=?", (new_status, decision, session.get("username", ""), now, review_id))
                db.execute("INSERT INTO redistribution_history(review_id,old_status,new_status,decision,actor,note,created_at) VALUES(?,?,?,?,?,?,?)", (review_id, "Pending", new_status, decision, session.get("username", ""), note, now))
                db.commit(); log_audit("redistribution_review_decision", str(review_id), f"{new_status}; note={note}; no transfer initiated")
                flash("Decision recorded. This only records review; it does not transfer or reserve stock.", "success")
            return redirect(url_for("resilience_workspace"))
        if action == "advisory":
            title=request.form.get("title", "").strip()[:120]; district=request.form.get("ad_district", "").strip()[:80]
            season=request.form.get("season", "").strip()[:80]; crop=request.form.get("crop", "").strip()[:80]
            advice=request.form.get("advice", "").strip()[:2000]; source=request.form.get("source_name", "").strip()[:200]
            source_url=request.form.get("source_url", "").strip()[:500]; status=request.form.get("advisory_status", "Illustrative sample")
            if not all((title,district,season,crop,advice,source)) or status not in ("Illustrative sample", "Official source verified"):
                flash("Complete all advisory fields and choose a valid status.", "error")
            elif status == "Official source verified" and (not source_url.startswith("https://") or "illustrative" in source.lower()):
                flash("To mark official, provide an HTTPS source URL and the real official source name.", "error")
            else:
                db.execute("INSERT INTO crop_advisories(title,district,season,crop,advice,source_name,source_url,updated_at,status) VALUES(?,?,?,?,?,?,?,?,?)", (title,district,season,crop,advice,source,source_url,now,status))
                db.commit(); log_audit("crop_advisory_added", title, f"status={status}; district={district}"); flash("Advisory saved.", "success")
            return redirect(url_for("resilience_workspace")+"#advisory")
    demands = db.execute("SELECT * FROM input_demands ORDER BY id DESC LIMIT 100").fetchall()
    reviews = db.execute("SELECT r.*,d.requester,d.village,d.district,d.input_type,d.quantity AS demand_qty,d.unit AS demand_unit,p.name AS paccs_name,p.village AS paccs_village,s.quantity AS stock_qty,s.unit AS stock_unit,s.valid_until,s.verified FROM redistribution_reviews r JOIN input_demands d ON d.id=r.demand_id JOIN demo_stock s ON s.id=r.stock_id JOIN demo_paccs p ON p.id=s.paccs_id ORDER BY r.id DESC LIMIT 100").fetchall()
    sites = db.execute("SELECT p.*, GROUP_CONCAT(s.input_type || ': ' || s.quantity || ' ' || s.unit || CASE WHEN s.verified=1 AND date(s.valid_until)>=date('now') THEN ' (verified/current)' ELSE ' (not eligible)' END, ' | ') AS stock_summary FROM demo_paccs p LEFT JOIN demo_stock s ON s.paccs_id=p.id GROUP BY p.id ORDER BY p.district,p.name").fetchall()
    advisories = db.execute("SELECT * FROM crop_advisories ORDER BY id DESC LIMIT 100").fetchall()
    history = db.execute("SELECT * FROM redistribution_history ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("resilience.html", demands=demands, reviews=reviews, sites=sites, advisories=advisories, history=history)

@app.errorhandler(403)
def forbidden(_):
    return render_template("403.html"), 403

@app.route("/health")
def health(): return {"status":"ok","app":"Vivasayi Connect TN Operations"}

@app.errorhandler(404)
def not_found(_): return render_template("404.html"),404

if __name__=="__main__": app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")

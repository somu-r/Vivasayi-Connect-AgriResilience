# Vivasayi Connect TN — Operations build

Flask + SQLite application for cooperative inventory, farmer supply requests, role-based dashboards, user administration, audit reporting, OTP sign-in/password recovery, low-stock notifications and SMS announcements. The app no longer inserts sample users, sample inventory or welcome/demo announcements into a fresh database. Screens show records entered by your organization.

## 1. Install and run on Windows

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Create a first administrator before the first run. In the same CMD window, set a unique username and a long password (at least 12 characters):

```bat
set BOOTSTRAP_ADMIN_USERNAME=your_admin_username
set BOOTSTRAP_ADMIN_PASSWORD=use_a_long_unique_password_here
set BOOTSTRAP_ADMIN_NAME=System Administrator
set SECRET_KEY=replace_with_a_long_random_secret
set OTP_SECRET=replace_with_a_different_long_random_secret
python app.py
```

Then open `http://127.0.0.1:5000`, log in with the bootstrap administrator, and create officer accounts from **User management**. Public registration creates farmer accounts only. The bootstrap administrator is created only if no administrator exists and valid bootstrap environment variables are supplied. Do not use example values as real passwords.

## 2. Set up real organizational data

1. Log in as an administrator and create officer accounts.
2. Open **Inventory** as an officer/admin. Add each product with its local/Tamil name, category, unit, opening balance and low-stock threshold. Enter actual stock counts from the cooperative ledger.
3. Record all incoming and outgoing stock movements in the same page so quantities and movement history stay in sync.
4. Farmers can register and submit requests. Use a registered mobile number consistently to associate requests with the farmer account.
5. Add verified phone/email contacts to accounts before enabling external notifications.

The database starts empty intentionally. This avoids fake inventory and fake recipient numbers being mistaken for real records. Existing database files are not automatically erased; back up before upgrading.

## 3. SMS and email configuration

### Twilio SMS

Set these in the same Windows CMD session before starting the app:

```bat
set TWILIO_ACCOUNT_SID=your_account_sid
set TWILIO_AUTH_TOKEN=your_rotated_auth_token
set TWILIO_FROM=+1xxxxxxxxxx
```

Use the actual SMS-capable sender number assigned to your Twilio account. Registered recipient numbers should use E.164 format, e.g. `+919876543210`. Check Twilio's supported destination countries, trial restrictions, message logs, delivery status and charges. Rotate any token that has been exposed. Never paste credentials into chat or commit them to source control.

### Email

```bat
set SMTP_HOST=smtp.example.com
set SMTP_PORT=587
set SMTP_FROM=notifications@example.com
set SMTP_USER=your_smtp_username
set SMTP_PASSWORD=your_smtp_password
```

Use your email provider's actual SMTP settings. Do not use these example values literally. OTP and notifications require correctly configured credentials and verified recipient contacts.

## 4. What is live and what still needs external setup?

- Dashboards, user management, requests, inventory, stock movements, reports and audit logs use the application's database.
- Low-stock notifications and announcement SMS attempt real provider sends only when Twilio/SMTP is configured. Provider acceptance does not guarantee final delivery; check provider logs.
- The IVR page is a database-backed on-screen enquiry assistant, **not a live telephone call**. Live voice IVR still requires a public HTTPS deployment, Twilio Voice number, voice webhook/TwiML flow, call status/error handling, consent and real-call testing.
- This is not yet a fully audited production service. Before public launch, add/verify CSRF protection, rate limiting, secure secret management, HTTPS, backups/restore tests, monitoring, data retention/privacy policy, access review and a security assessment. Use a production WSGI server (e.g. Gunicorn) rather than Flask's development server.

## 5. Environment notes

- `DATABASE_PATH` can point to a persistent SQLite file. For multiple concurrent production workers or larger deployments, migrate to PostgreSQL.
- `APP_ENV=production` disables local OTP fallback disclosure; configure real delivery first.
- Set a strong, unique `SECRET_KEY` and a different `OTP_SECRET` outside source control.
- Existing demo accounts/rows in a database from an earlier version are not deleted automatically. Disable/remove those records manually after confirming they are not real accounts.
